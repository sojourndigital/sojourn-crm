<?php

namespace Tests\Feature;

use App\Models\Company;
use App\Models\Contact;
use App\Models\Deal;
use App\Models\Activity;
use App\Models\Membership;
use App\Models\Task;
use App\Models\User;
use App\Models\Workspace;
use App\Services\AuditLogger;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Mockery\MockInterface;
use Tests\TestCase;

class CrmWriteApiTest extends TestCase
{
    use RefreshDatabase;

    public function test_member_can_log_a_note_against_a_workspace_contact(): void
    {
        [$user, $workspace] = $this->memberWithWorkspace();
        $contact = Contact::factory()->create(['workspace_id' => $workspace->id]);

        $this->actingAs($user)->postJson(route('activities.store', $workspace), [
            'subject_type' => 'contact', 'subject_id' => $contact->id, 'body' => 'Follow up next week.',
        ])->assertCreated()->assertJsonPath('data.type', 'note');

        $this->assertDatabaseHas('activities', ['workspace_id' => $workspace->id, 'subject_id' => $contact->id, 'type' => 'note', 'body' => 'Follow up next week.']);
    }

    public function test_member_can_create_a_contact_for_their_workspace(): void
    {
        [$user, $workspace] = $this->memberWithWorkspace();
        $company = Company::factory()->create(['workspace_id' => $workspace->id]);

        $response = $this->actingAs($user)->postJson(route('contacts.store', $workspace), [
            'first_name' => 'Avery',
            'last_name' => 'Reed',
            'email' => 'avery@example.test',
            'company_id' => $company->id,
            'lifecycle_stage' => 'lead',
        ]);

        $response->assertCreated()->assertJsonPath('first_name', 'Avery');
        $this->assertDatabaseHas('contacts', [
            'workspace_id' => $workspace->id,
            'company_id' => $company->id,
            'email' => 'avery@example.test',
        ]);
        $this->assertDatabaseHas('audit_events', [
            'workspace_id' => $workspace->id,
            'actor_user_id' => $user->id,
            'action' => 'contact.created',
        ]);
    }

    public function test_contact_cannot_reference_a_company_from_another_workspace(): void
    {
        [$user, $workspace] = $this->memberWithWorkspace();
        $otherCompany = Company::factory()->create();

        $response = $this->actingAs($user)->postJson(route('contacts.store', $workspace), [
            'first_name' => 'Avery',
            'company_id' => $otherCompany->id,
        ]);

        $response->assertUnprocessable()->assertJsonValidationErrors(['company_id']);
        $this->assertDatabaseMissing('contacts', ['first_name' => 'Avery']);
    }

    public function test_contact_creation_is_rolled_back_when_audit_logging_fails(): void
    {
        [$user, $workspace] = $this->memberWithWorkspace();

        $this->mock(AuditLogger::class, function (MockInterface $mock): void {
            $mock->shouldReceive('record')->once()->andThrow(new \RuntimeException('Audit storage unavailable.'));
        });

        $this->actingAs($user)
            ->postJson(route('contacts.store', $workspace), [
                'first_name' => 'Avery',
                'email' => 'avery@example.test',
            ])
            ->assertServerError();

        $this->assertDatabaseMissing('contacts', [
            'workspace_id' => $workspace->id,
            'email' => 'avery@example.test',
        ]);
    }

    public function test_member_cannot_read_a_contact_in_another_workspace(): void
    {
        [$user, $workspace] = $this->memberWithWorkspace();
        $otherWorkspace = Workspace::factory()->create();
        $contact = Contact::factory()->create(['workspace_id' => $otherWorkspace->id]);

        $this->actingAs($user)
            ->getJson(route('contacts.show', [$otherWorkspace, $contact]))
            ->assertNotFound();
    }

    public function test_member_cannot_update_a_company_in_another_workspace(): void
    {
        [$user, $workspace] = $this->memberWithWorkspace();
        $otherWorkspace = Workspace::factory()->create();
        $company = Company::factory()->create(['workspace_id' => $otherWorkspace->id, 'name' => 'Private Company']);

        $this->actingAs($user)
            ->patchJson(route('companies.update', [$workspace, $company]), ['name' => 'Changed Name'])
            ->assertNotFound();

        $this->assertDatabaseHas('companies', [
            'id' => $company->id,
            'workspace_id' => $otherWorkspace->id,
            'name' => 'Private Company',
        ]);
    }

    public function test_completing_task_records_the_actor_and_completion_time(): void
    {
        [$user, $workspace] = $this->memberWithWorkspace();
        $task = Task::factory()->create(['workspace_id' => $workspace->id, 'status' => 'open']);

        $response = $this->actingAs($user)->patchJson(route('tasks.update', [$workspace, $task]), [
            'status' => 'completed',
        ]);

        $response->assertOk()->assertJsonPath('status', 'completed');
        $this->assertDatabaseHas('tasks', [
            'id' => $task->id,
            'status' => 'completed',
            'completed_by_user_id' => $user->id,
        ]);
        $this->assertNotNull($task->fresh()->completed_at);
    }

    public function test_member_can_move_a_deal_and_the_change_is_audited(): void
    {
        [$user, $workspace] = $this->memberWithWorkspace();
        $deal = Deal::factory()->create(['workspace_id' => $workspace->id, 'stage' => 'new']);

        $response = $this->actingAs($user)->patchJson(route('deals.update', [$workspace, $deal]), [
            'stage' => 'proposal',
        ]);

        $response->assertOk()->assertJsonPath('stage', 'proposal');
        $this->assertDatabaseHas('deals', ['id' => $deal->id, 'stage' => 'proposal']);
        $this->assertDatabaseHas('audit_events', [
            'workspace_id' => $workspace->id,
            'actor_user_id' => $user->id,
            'action' => 'deal.updated',
        ]);
    }

    public function test_closing_and_reopening_a_deal_updates_its_closed_timestamp(): void
    {
        [$user, $workspace] = $this->memberWithWorkspace();
        $deal = Deal::factory()->create(['workspace_id' => $workspace->id, 'stage' => 'proposal']);

        $this->actingAs($user)
            ->patchJson(route('deals.update', [$workspace, $deal]), ['stage' => 'closed_won'])
            ->assertOk()
            ->assertJsonPath('stage', 'closed_won');

        $this->assertNotNull($deal->fresh()->closed_at);

        $this->actingAs($user)
            ->patchJson(route('deals.update', [$workspace, $deal]), ['stage' => 'qualified'])
            ->assertOk()
            ->assertJsonPath('stage', 'qualified');

        $this->assertNull($deal->fresh()->closed_at);
    }

    /**
     * @return array{User, Workspace}
     */
    private function memberWithWorkspace(): array
    {
        $user = User::factory()->create();
        $workspace = Workspace::factory()->create();
        Membership::factory()->create(['user_id' => $user->id, 'workspace_id' => $workspace->id]);

        return [$user, $workspace];
    }
}
