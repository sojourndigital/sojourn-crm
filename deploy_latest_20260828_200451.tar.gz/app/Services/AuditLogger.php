<?php

namespace App\Services;

use App\Models\AuditEvent;
use App\Models\User;
use App\Models\Workspace;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class AuditLogger
{
    /**
     * @param  array<string, mixed>|null  $before
     */
    public function record(Model $model, Workspace $workspace, ?User $actor, string $action, ?array $before = null): void
    {
        $requestId = request()->header('X-Request-Id');

        AuditEvent::create([
            'workspace_id' => $workspace->id,
            'actor_user_id' => $actor?->id,
            'auditable_type' => $model->getMorphClass(),
            'auditable_id' => $model->getKey(),
            'action' => $action,
            'source' => 'application',
            'request_id' => is_string($requestId) && Str::isUuid($requestId) ? $requestId : null,
            'before' => $before,
            'after' => $model->getAttributes(),
            'occurred_at' => now(),
        ]);
    }
}
