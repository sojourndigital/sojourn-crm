<?php

use App\Http\Controllers\Api\CompanyController;
use App\Http\Controllers\Api\ContactController;
use App\Http\Controllers\Api\DealController;
use App\Http\Controllers\Api\ActivityController;
use App\Http\Controllers\Api\TaskController;
use App\Http\Controllers\AuthenticatedSessionController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\WorkspaceActivityController;
use App\Http\Controllers\WorkspaceCompanyController;
use App\Http\Controllers\WorkspaceContactController;
use App\Http\Controllers\WorkspacePipelineController;
use App\Http\Controllers\WorkspaceTaskController;
use App\Http\Middleware\EnsureWorkspaceMembership;
use Illuminate\Support\Facades\Route;

Route::middleware('guest')->group(function (): void {
    Route::get('/login', [AuthenticatedSessionController::class, 'create'])->name('login');
    Route::post('/login', [AuthenticatedSessionController::class, 'store'])
        ->middleware('throttle:login')
        ->name('login.store');
    Route::get('/auth/{provider}/redirect', [AuthenticatedSessionController::class, 'redirect'])
        ->middleware('throttle:oauth')
        ->whereIn('provider', ['google', 'microsoft'])
        ->name('oauth.redirect');
    Route::get('/auth/{provider}/callback', [AuthenticatedSessionController::class, 'callback'])
        ->middleware('throttle:oauth')
        ->whereIn('provider', ['google', 'microsoft'])
        ->name('oauth.callback');
});

Route::middleware('auth')->group(function (): void {
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/workspaces/{workspace:slug}', [DashboardController::class, 'show'])->name('workspaces.dashboard');
    Route::get('/workspaces/{workspace:slug}/people', [WorkspaceContactController::class, 'index'])
        ->middleware(EnsureWorkspaceMembership::class)
        ->name('workspace.contacts');
    Route::get('/workspaces/{workspace:slug}/people/{contact}', [WorkspaceContactController::class, 'show'])
        ->middleware(EnsureWorkspaceMembership::class)
        ->scopeBindings()
        ->name('workspace.contact');
    Route::get('/workspaces/{workspace:slug}/organizations', [WorkspaceCompanyController::class, 'index'])
        ->middleware(EnsureWorkspaceMembership::class)
        ->name('workspace.companies');
    Route::get('/workspaces/{workspace:slug}/organizations/{company}', [WorkspaceCompanyController::class, 'show'])
        ->middleware(EnsureWorkspaceMembership::class)
        ->scopeBindings()
        ->name('workspace.company');
    Route::get('/workspaces/{workspace:slug}/activity', [WorkspaceActivityController::class, 'index'])
        ->middleware(EnsureWorkspaceMembership::class)
        ->name('workspace.activity');
    Route::get('/workspaces/{workspace:slug}/pipeline', [WorkspacePipelineController::class, 'index'])
        ->middleware(EnsureWorkspaceMembership::class)
        ->name('workspace.pipeline');
    Route::get('/workspaces/{workspace:slug}/pipeline/{deal}', [WorkspacePipelineController::class, 'show'])
        ->middleware(EnsureWorkspaceMembership::class)
        ->scopeBindings()
        ->name('workspace.deal');
    Route::get('/workspaces/{workspace:slug}/to-dos', [WorkspaceTaskController::class, 'index'])
        ->middleware(EnsureWorkspaceMembership::class)
        ->name('workspace.tasks');
    Route::post('/logout', [AuthenticatedSessionController::class, 'destroy'])->name('logout');

    Route::prefix('workspaces/{workspace:slug}')
        ->middleware(EnsureWorkspaceMembership::class)
        ->scopeBindings()
        ->group(function (): void {
            Route::apiResource('companies', CompanyController::class);
            Route::apiResource('contacts', ContactController::class);
            Route::apiResource('deals', DealController::class);
            Route::apiResource('tasks', TaskController::class);
            Route::post('activities', [ActivityController::class, 'store'])->name('activities.store');
        });
});
