<?php

namespace App\Http\Requests;

use App\Models\Company;
use App\Models\Contact;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreDealRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'company_id' => ['nullable', Rule::exists(Company::class, 'id')->where('workspace_id', $this->route('workspace')->id)],
            'contact_id' => ['nullable', Rule::exists(Contact::class, 'id')->where('workspace_id', $this->route('workspace')->id)],
            'name' => ['required', 'string', 'max:255'],
            'pipeline' => ['nullable', 'string', 'max:100'],
            'stage' => ['nullable', Rule::in(['new', 'qualified', 'proposal', 'negotiation', 'closed_won', 'closed_lost'])],
            'amount' => ['nullable', 'numeric', 'min:0', 'max:999999999999.99'],
            'currency' => ['nullable', 'string', 'size:3'],
            'probability' => ['nullable', 'integer', 'between:0,100'],
            'expected_close_at' => ['nullable', 'date'],
            'properties' => ['nullable', 'array'],
        ];
    }
}
