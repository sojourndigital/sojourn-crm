<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class OAuthAuthenticationTest extends TestCase
{
    use RefreshDatabase;

    public function test_login_page_explains_that_unconfigured_providers_are_unavailable(): void
    {
        config()->set('services.google.client_id', null);
        config()->set('services.microsoft.client_id', null);

        $this->get(route('login'))
            ->assertOk()
            ->assertSee('Google sign-in is coming soon')
            ->assertSee('Microsoft sign-in is coming soon');
    }

    public function test_unconfigured_provider_returns_to_login_without_redirecting_off_site(): void
    {
        config()->set('services.google.client_id', null);

        $this->get(route('oauth.redirect', 'google'))
            ->assertRedirect(route('login'))
            ->assertSessionHas('status', 'Google sign-in is not configured yet.');
    }

    public function test_oauth_redirect_requests_are_rate_limited(): void
    {
        config()->set('services.google.client_id', null);

        for ($attempt = 0; $attempt < 10; $attempt++) {
            $this->get(route('oauth.redirect', 'google'))->assertRedirect(route('login'));
        }

        $this->get(route('oauth.redirect', 'google'))->assertTooManyRequests();
    }

    public function test_oauth_callback_rejects_a_state_value_that_does_not_match_the_session(): void
    {
        config()->set('services.google.client_id', 'client-id');
        config()->set('services.google.client_secret', 'client-secret');
        config()->set('services.google.redirect', 'http://localhost/auth/google/callback');

        $this->withSession(['oauth_state.google' => 'expected-state'])
            ->get(route('oauth.callback', ['provider' => 'google', 'state' => 'forged-state', 'code' => 'unused']))
            ->assertForbidden();
    }
}
