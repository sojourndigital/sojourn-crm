<?php

namespace Tests\Feature;

use App\Models\Deal;
use App\Models\Membership;
use App\Models\User;
use App\Models\Workspace;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class WorkspacePipelineTest extends TestCase
{
    use RefreshDatabase;

    public function test_member_sees_only_their_workspace_pipeline(): void
    {
        $user = User::factory()->create();
        $workspace = Workspace::factory()->create(['name' => 'North Workspace']);
        Membership::factory()->create(['user_id' => $user->id, 'workspace_id' => $workspace->id]);
        Deal::factory()->create(['workspace_id' => $workspace->id, 'name' => 'Visible Opportunity', 'stage' => 'proposal', 'amount' => 8000]);
        Deal::factory()->create(['name' => 'Other Opportunity', 'stage' => 'proposal']);

        $response = $this->actingAs($user)->get(route('workspace.pipeline', $workspace));

        $response->assertOk();
        $response->assertSee('Visible Opportunity');
        $response->assertDontSee('Other Opportunity');
        $response->assertSee('Proposal');
    }

    public function test_member_cannot_open_another_workspaces_pipeline(): void
    {
        $user = User::factory()->create();
        $workspace = Workspace::factory()->create();
        $otherWorkspace = Workspace::factory()->create();
        Membership::factory()->create(['user_id' => $user->id, 'workspace_id' => $workspace->id]);

        $this->actingAs($user)
            ->get(route('workspace.pipeline', $otherWorkspace))
            ->assertNotFound();
    }

    public function test_member_can_open_a_deal_detail_page_with_tasks_and_history(): void
    {
        $user = User::factory()->create();
        $workspace = Workspace::factory()->create();
        Membership::factory()->create(['user_id' => $user->id, 'workspace_id' => $workspace->id]);
        $deal = Deal::factory()->create(['workspace_id' => $workspace->id, 'name' => 'Annual contract']);

        $this->actingAs($user)
            ->get(route('workspace.deal', [$workspace, $deal]))
            ->assertOk()
            ->assertSee('Annual contract')
            ->assertSee('Open tasks');
    }

    public function test_member_cannot_open_a_deal_detail_from_another_workspace(): void
    {
        $user = User::factory()->create();
        $workspace = Workspace::factory()->create();
        $otherWorkspace = Workspace::factory()->create();
        Membership::factory()->create(['user_id' => $user->id, 'workspace_id' => $workspace->id]);
        $deal = Deal::factory()->create(['workspace_id' => $otherWorkspace->id]);

        $this->actingAs($user)
            ->get(route('workspace.deal', [$workspace, $deal]))
            ->assertNotFound();
    }
}
