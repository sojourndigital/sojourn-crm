<?php

namespace App\Http\Controllers;

use App\Models\IdentityProvider;
use App\Models\User;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

class AuthenticatedSessionController extends Controller
{
    private const array PROVIDERS = ['google', 'microsoft'];

    public function create(): View
    {
        return view('auth.login', [
            'providers' => collect(self::PROVIDERS)->mapWithKeys(fn (string $provider): array => [$provider => $this->providerIsConfigured($provider)]),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required', 'string'],
        ]);

        if (! Auth::attempt($request->only('email', 'password'), false)) {
            return to_route('login')->with('status', 'Those credentials do not match a provisioned account.');
        }

        $request->session()->regenerate();

        return to_route('dashboard');
    }

    public function redirect(Request $request, string $provider): RedirectResponse
    {
        $this->ensureKnownProvider($provider);

        if (! $this->providerIsConfigured($provider)) {
            return to_route('login')->with('status', ucfirst($provider).' sign-in is not configured yet.');
        }

        $state = Str::random(64);
        $request->session()->put("oauth_state.{$provider}", $state);

        return redirect()->away($this->authorizationUrl($provider, $state));
    }

    public function callback(Request $request, string $provider): RedirectResponse
    {
        $this->ensureKnownProvider($provider);

        $expectedState = $request->session()->pull("oauth_state.{$provider}");

        abort_unless(is_string($expectedState) && hash_equals($expectedState, (string) $request->string('state')), 403);

        if ($request->filled('error')) {
            return to_route('login')->with('status', 'Sign-in was cancelled or not approved.');
        }

        $code = $request->string('code')->toString();
        abort_if($code === '', 422);

        $accessToken = $this->accessToken($provider, $code);
        $profile = $this->profile($provider, $accessToken);
        $email = strtolower((string) ($profile['email'] ?? ''));
        $providerUserId = (string) ($profile['id'] ?? '');

        if ($email === '' || $providerUserId === '') {
            return to_route('login')->with('status', 'Your identity provider did not return the required account details.');
        }

        $identity = IdentityProvider::query()->where([
            'provider' => $provider,
            'provider_user_id' => $providerUserId,
        ])->first();

        if ($identity === null) {
            $user = User::query()->whereRaw('lower(email) = ?', [$email])->first();

            if ($user === null) {
                return to_route('login')->with('status', 'This account has not been provisioned for Sojourn CRM.');
            }

            $identity = IdentityProvider::create([
                'user_id' => $user->id,
                'provider' => $provider,
                'provider_user_id' => $providerUserId,
                'provider_email' => $email,
                'profile' => $profile,
            ]);
        } else {
            $identity->update([
                'provider_email' => $email,
                'profile' => $profile,
            ]);
        }

        Auth::login($identity->user);
        $request->session()->regenerate();

        return to_route('dashboard');
    }

    public function destroy(Request $request): RedirectResponse
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return to_route('login');
    }

    private function ensureKnownProvider(string $provider): void
    {
        abort_unless(in_array($provider, self::PROVIDERS, true), 404);
    }

    private function providerIsConfigured(string $provider): bool
    {
        return filled(config("services.{$provider}.client_id"))
            && filled(config("services.{$provider}.client_secret"))
            && filled(config("services.{$provider}.redirect"))
            && ($provider !== 'microsoft' || filled(config('services.microsoft.tenant')));
    }

    private function authorizationUrl(string $provider, string $state): string
    {
        $parameters = [
            'client_id' => config("services.{$provider}.client_id"),
            'redirect_uri' => config("services.{$provider}.redirect"),
            'response_type' => 'code',
            'scope' => $provider === 'google' ? 'openid email profile' : 'openid profile email User.Read',
            'state' => $state,
        ];

        if ($provider === 'google') {
            $parameters['access_type'] = 'online';
            $parameters['prompt'] = 'select_account';

            return 'https://accounts.google.com/o/oauth2/v2/auth?'.http_build_query($parameters, '', '&', PHP_QUERY_RFC3986);
        }

        return 'https://login.microsoftonline.com/'.rawurlencode((string) config('services.microsoft.tenant')).'/oauth2/v2.0/authorize?'.http_build_query($parameters, '', '&', PHP_QUERY_RFC3986);
    }

    private function accessToken(string $provider, string $code): string
    {
        $tokenUrl = $provider === 'google'
            ? 'https://oauth2.googleapis.com/token'
            : 'https://login.microsoftonline.com/'.rawurlencode((string) config('services.microsoft.tenant')).'/oauth2/v2.0/token';

        $token = Http::asForm()
            ->connectTimeout(3)
            ->timeout(10)
            ->post($tokenUrl, [
                'client_id' => config("services.{$provider}.client_id"),
                'client_secret' => config("services.{$provider}.client_secret"),
                'redirect_uri' => config("services.{$provider}.redirect"),
                'grant_type' => 'authorization_code',
                'code' => $code,
            ])
            ->throw()
            ->json();

        $accessToken = is_array($token) ? $token['access_token'] ?? null : null;

        abort_unless(is_string($accessToken) && $accessToken !== '', 502);

        return $accessToken;
    }

    /**
     * @return array<string, mixed>
     */
    private function profile(string $provider, string $accessToken): array
    {
        if ($provider === 'google') {
            $profile = Http::withToken($accessToken)
                ->connectTimeout(3)
                ->timeout(10)
                ->get('https://openidconnect.googleapis.com/v1/userinfo')
                ->throw()
                ->json();

            abort_unless(is_array($profile) && ($profile['email_verified'] ?? false) === true, 403);

            return [
                'id' => $profile['sub'] ?? null,
                'email' => $profile['email'] ?? null,
                'name' => $profile['name'] ?? null,
                'raw' => $profile,
            ];
        }

        $profile = Http::withToken($accessToken)
            ->connectTimeout(3)
            ->timeout(10)
            ->get('https://graph.microsoft.com/v1.0/me?$select=id,displayName,mail,userPrincipalName,givenName,surname')
            ->throw()
            ->json();

        abort_unless(is_array($profile), 502);

        return [
            'id' => $profile['id'] ?? null,
            'email' => $profile['mail'] ?? $profile['userPrincipalName'] ?? null,
            'name' => $profile['displayName'] ?? null,
            'raw' => $profile,
        ];
    }
}
