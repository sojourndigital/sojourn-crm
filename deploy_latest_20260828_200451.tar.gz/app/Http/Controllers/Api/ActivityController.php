<?php

namespace App\Http\Controllers\Api;

use App\Models\Activity;
use App\Models\Company;
use App\Models\Contact;
use App\Models\Deal;
use App\Models\Workspace;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ActivityController
{
    public function store(Request $request, Workspace $workspace): JsonResponse
    {
        $data = $request->validate(['subject_type' => ['required', 'in:contact,company,deal'], 'subject_id' => ['required', 'integer'], 'body' => ['required', 'string', 'max:10000']]);
        $types = ['contact' => Contact::class, 'company' => Company::class, 'deal' => Deal::class];
        $subject = $types[$data['subject_type']]::query()->whereBelongsTo($workspace)->findOrFail($data['subject_id']);
        $activity = Activity::create(['workspace_id' => $workspace->id, 'actor_user_id' => $request->user()->id, 'subject_type' => $subject::class, 'subject_id' => $subject->id, 'type' => 'note', 'body' => $data['body'], 'occurred_at' => now()]);
        return response()->json(['data' => $activity], 201);
    }
}
