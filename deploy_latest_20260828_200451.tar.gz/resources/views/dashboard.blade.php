<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <title>CRM Dashboard · Sojourn</title>
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    </head>
    <body class="min-h-screen bg-slate-100 text-slate-900 antialiased">
        <div class="min-h-screen lg:grid lg:grid-cols-[15rem_1fr]">
            <aside class="bg-slate-950 px-5 py-6 text-slate-300 lg:min-h-screen">
                <a href="{{ route('dashboard') }}" class="flex items-center gap-3 text-white">
                    <span class="grid size-9 place-items-center rounded-xl bg-orange-500 text-sm font-black">S</span>
                    <span class="font-semibold tracking-tight">Sojourn CRM</span>
                </a>

                <nav class="mt-9 grid gap-1 text-sm">
                    <a href="{{ route('dashboard') }}" class="rounded-lg bg-white/10 px-3 py-2.5 font-medium text-white">Overview</a>
                    @if ($workspace !== null)<a href="{{ route('workspace.contacts', $workspace) }}" class="rounded-lg px-3 py-2.5 text-slate-400 hover:bg-white/5 hover:text-white">Contacts</a>@else<span class="rounded-lg px-3 py-2.5 text-slate-500">Contacts</span>@endif
                    @if ($workspace !== null)<a href="{{ route('workspace.companies', $workspace) }}" class="rounded-lg px-3 py-2.5 text-slate-400 hover:bg-white/5 hover:text-white">Companies</a>@else<span class="rounded-lg px-3 py-2.5 text-slate-500">Companies</span>@endif
                    @if ($workspace !== null)<a href="{{ route('workspace.pipeline', $workspace) }}" class="rounded-lg px-3 py-2.5 text-slate-400 hover:bg-white/5 hover:text-white">Deals</a>@else<span class="rounded-lg px-3 py-2.5 text-slate-500">Deals</span>@endif
                    @if ($workspace !== null)<a href="{{ route('workspace.tasks', $workspace) }}" class="rounded-lg px-3 py-2.5 text-slate-400 hover:bg-white/5 hover:text-white">Tasks</a>@else<span class="rounded-lg px-3 py-2.5 text-slate-500">Tasks</span>@endif
                </nav>

                <div class="mt-10 border-t border-white/10 pt-5">
                    <p class="px-3 text-xs font-medium tracking-wide text-slate-500 uppercase">Workspace</p>
                    <div class="mt-2 grid gap-1">
                        @foreach ($workspaces as $availableWorkspace)
                            <a href="{{ route('workspaces.dashboard', $availableWorkspace) }}" class="rounded-lg px-3 py-2 text-sm {{ $workspace?->is($availableWorkspace) ? 'bg-white/10 text-white' : 'text-slate-400 hover:bg-white/5 hover:text-white' }}">{{ $availableWorkspace->name }}</a>
                        @endforeach
                    </div>
                </div>

                <form method="POST" action="{{ route('logout') }}" class="mt-10">
                    @csrf
                    <button type="submit" class="px-3 text-sm text-slate-500 hover:text-white">Sign out</button>
                </form>
            </aside>

            <main class="p-6 sm:p-10">
                @if ($workspace === null)
                    <section class="mx-auto flex min-h-[60vh] max-w-xl items-center">
                        <div>
                            <p class="text-sm font-semibold tracking-wide text-orange-600 uppercase">Getting started</p>
                            <h1 class="mt-3 text-3xl font-semibold tracking-tight">No workspace yet</h1>
                            <p class="mt-3 text-slate-600">An administrator can add you to a workspace to begin using Sojourn CRM.</p>
                        </div>
                    </section>
                @else
                    <header class="flex flex-wrap items-end justify-between gap-4">
                        <div>
                            <p class="text-sm font-medium text-orange-600">{{ $workspace->name }}</p>
                            <h1 class="mt-1 text-3xl font-semibold tracking-tight">Good to see you, {{ auth()->user()->name }}.</h1>
                            <p class="mt-2 text-sm text-slate-500">A clear view of the relationships and work that need attention.</p>
                        </div>
                        <div class="flex flex-wrap items-center gap-2"><a href="#new-contact" class="rounded-lg bg-orange-500 px-3 py-2 text-sm font-semibold text-white hover:bg-orange-600">Add contact</a><a href="#new-company" class="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50">Add company</a><a href="#new-deal" class="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50">Add deal</a><a href="#new-task" class="rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50">Add task</a></div>
                    </header>

                    <section class="mt-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                        @foreach ([['Open deals', number_format($stats['open_deals']), 'In active pipeline', route('workspace.pipeline', $workspace)], ['Pipeline value', '$'.number_format((float) $stats['pipeline_value'], 0), 'Open deal value', route('workspace.pipeline', $workspace)], ['Due today', number_format($stats['tasks_due_today']), 'Tasks due today', route('workspace.tasks', $workspace)], ['Overdue', number_format($stats['tasks_overdue']), 'Open tasks past due', route('workspace.tasks', $workspace)]] as [$label, $value, $description, $link])
                            <a href="{{ $link }}" class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:border-orange-300">
                                <p class="text-sm font-medium text-slate-500">{{ $label }}</p>
                                <p class="mt-4 text-3xl font-semibold tracking-tight">{{ $value }}</p>
                                <p class="mt-2 text-xs text-slate-400">{{ $description }}</p>
                            </a>
                        @endforeach
                    </section>

                    <section class="mt-8 grid gap-6 xl:grid-cols-[1.5fr_1fr]">
                        <article class="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                            <div class="flex items-center justify-between">
                                <div>
                                    <h2 class="font-semibold">Active pipeline</h2>
                                    <p class="mt-1 text-sm text-slate-500">The deals currently moving forward.</p>
                                </div>
                                <span class="text-xs font-medium text-slate-400">{{ $deals->count() }} shown</span>
                            </div>
                            <div class="mt-5 overflow-x-auto">
                                <table class="w-full min-w-[34rem] text-left text-sm">
                                    <thead class="border-b border-slate-100 text-xs tracking-wide text-slate-400 uppercase">
                                        <tr><th class="pb-3 font-medium">Deal</th><th class="pb-3 font-medium">Stage</th><th class="pb-3 text-right font-medium">Value</th></tr>
                                    </thead>
                                    <tbody class="divide-y divide-slate-100">
                                        @forelse ($deals as $deal)
                                            <tr><td class="py-4"><p class="font-medium text-slate-800">{{ $deal->name }}</p><p class="mt-0.5 text-xs text-slate-400">{{ $deal->company?->name ?? $deal->contact?->first_name.' '.$deal->contact?->last_name }}</p></td><td class="py-4"><span class="rounded-full bg-orange-50 px-2.5 py-1 text-xs font-medium text-orange-700">{{ str($deal->stage)->replace('_', ' ')->title() }}</span></td><td class="py-4 text-right font-medium">${{ number_format((float) $deal->amount, 0) }}</td></tr>
                                        @empty
                                            <tr><td colspan="3" class="py-8 text-center text-slate-500">No active deals yet.</td></tr>
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </article>

                        <article class="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                            <h2 class="font-semibold">Pipeline by stage</h2>
                            <p class="mt-1 text-sm text-slate-500">Value concentrated in each stage.</p>
                            <div class="mt-5 grid gap-4">
                                @forelse ($dealsByStage as $stage)
                                    <div class="flex items-center justify-between gap-4"><div><p class="text-sm font-medium">{{ str($stage->stage)->replace('_', ' ')->title() }}</p><p class="text-xs text-slate-400">{{ $stage->deal_count }} {{ str('deal')->plural($stage->deal_count) }}</p></div><p class="text-sm font-semibold">${{ number_format((float) $stage->total_amount, 0) }}</p></div>
                                @empty
                                    <p class="py-5 text-sm text-slate-500">No pipeline data yet.</p>
                                @endforelse
                            </div>
                        </article>
                    </section>

                    <section class="mt-8 grid gap-6 xl:grid-cols-2">
                        <article class="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"><div class="flex items-center justify-between"><h2 class="font-semibold">Task queue</h2><a href="#new-task" class="text-sm font-medium text-orange-600 hover:text-orange-700">New task</a></div><div class="mt-5 grid gap-3">@forelse ($tasks as $task)<div class="rounded-xl bg-slate-50 px-4 py-3"><div class="flex items-center justify-between gap-4"><div><p class="text-sm font-medium">{{ $task->title }}</p><p class="mt-1 text-xs text-slate-500">{{ $task->assignedUser?->name ?? 'Unassigned' }}</p></div><div class="flex shrink-0 items-center gap-3"><span class="text-xs text-slate-400">{{ $task->due_at?->format('M j') ?? 'No due date' }}</span><button type="button" data-complete-task="{{ route('tasks.update', [$workspace, $task]) }}" class="rounded-lg border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-semibold text-slate-700 hover:border-orange-500 hover:text-orange-700 disabled:cursor-wait disabled:opacity-60">Complete</button></div></div></div>@empty<p class="py-5 text-sm text-slate-500">No open tasks.</p>@endforelse</div></article>
                        <article class="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"><div class="flex items-center justify-between"><h2 class="font-semibold">Recent contacts</h2><a href="#new-contact" class="text-sm font-medium text-orange-600 hover:text-orange-700">New contact</a></div><div class="mt-5 grid gap-3">@forelse ($contacts as $contact)<div class="flex items-center justify-between gap-4 rounded-xl bg-slate-50 px-4 py-3"><div><p class="text-sm font-medium">{{ $contact->first_name }} {{ $contact->last_name }}</p><p class="mt-1 text-xs text-slate-500">{{ $contact->company?->name ?? $contact->email }}</p></div><span class="text-xs font-medium text-slate-400">{{ str($contact->lifecycle_stage)->replace('_', ' ')->title() }}</span></div>@empty<p class="py-5 text-sm text-slate-500">No contacts yet.</p>@endforelse</div></article>
                    </section>

                    <section class="mt-8 grid gap-6 xl:grid-cols-2">
                        <article id="new-contact" class="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"><h2 class="font-semibold">Add contact</h2><p class="mt-1 text-sm text-slate-500">Start a relationship record in this workspace.</p><form method="POST" action="{{ route('contacts.store', $workspace) }}" data-crm-form class="mt-5 grid gap-4"><div class="grid gap-4 sm:grid-cols-2"><label class="grid gap-1.5 text-sm font-medium">First name<input required name="first_name" class="rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-orange-500" autocomplete="given-name"></label><label class="grid gap-1.5 text-sm font-medium">Last name<input name="last_name" class="rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-orange-500" autocomplete="family-name"></label></div><label class="grid gap-1.5 text-sm font-medium">Email<input name="email" type="email" class="rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-orange-500" autocomplete="email"></label><label class="grid gap-1.5 text-sm font-medium">Phone<input name="phone" type="tel" class="rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-orange-500" autocomplete="tel"></label><p data-form-error class="hidden rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700"></p><button type="submit" data-default-label="Save contact" class="justify-self-start rounded-lg bg-slate-950 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-800 disabled:cursor-wait disabled:opacity-60">Save contact</button></form></article>
                        <article id="new-company" class="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"><h2 class="font-semibold">Add company</h2><p class="mt-1 text-sm text-slate-500">Create the organization a relationship belongs to.</p><form method="POST" action="{{ route('companies.store', $workspace) }}" data-crm-form class="mt-5 grid gap-4"><label class="grid gap-1.5 text-sm font-medium">Company name<input required name="name" class="rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-orange-500" autocomplete="organization"></label><label class="grid gap-1.5 text-sm font-medium">Website<input name="domain" type="url" class="rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-orange-500" placeholder="https://example.com"></label><label class="grid gap-1.5 text-sm font-medium">Phone<input name="phone" type="tel" class="rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-orange-500" autocomplete="tel"></label><p data-form-error class="hidden rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700"></p><button type="submit" data-default-label="Save company" class="justify-self-start rounded-lg bg-slate-950 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-800 disabled:cursor-wait disabled:opacity-60">Save company</button></form></article>
                        <article id="new-deal" class="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"><h2 class="font-semibold">Add deal</h2><p class="mt-1 text-sm text-slate-500">Start a new opportunity in the sales pipeline.</p><form method="POST" action="{{ route('deals.store', $workspace) }}" data-crm-form class="mt-5 grid gap-4"><label class="grid gap-1.5 text-sm font-medium">Deal name<input required name="name" class="rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-orange-500"></label><div class="grid gap-4 sm:grid-cols-2"><label class="grid gap-1.5 text-sm font-medium">Value (CAD)<input name="amount" type="number" min="0" step="0.01" class="rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-orange-500"></label><label class="grid gap-1.5 text-sm font-medium">Stage<select name="stage" class="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500"><option value="new">New</option><option value="qualified">Qualified</option><option value="proposal">Proposal</option><option value="negotiation">Negotiation</option><option value="closed_won">Closed won</option><option value="closed_lost">Closed lost</option></select></label></div><label class="grid gap-1.5 text-sm font-medium">Expected close<input name="expected_close_at" type="datetime-local" class="rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-orange-500"></label><p data-form-error class="hidden rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700"></p><button type="submit" data-default-label="Save deal" class="justify-self-start rounded-lg bg-slate-950 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-800 disabled:cursor-wait disabled:opacity-60">Save deal</button></form></article>
                        <article id="new-task" class="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"><h2 class="font-semibold">Add task</h2><p class="mt-1 text-sm text-slate-500">Give the team a clear next step.</p><form method="POST" action="{{ route('tasks.store', $workspace) }}" data-crm-form class="mt-5 grid gap-4"><label class="grid gap-1.5 text-sm font-medium">Task<input required name="title" class="rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-orange-500"></label><div class="grid gap-4 sm:grid-cols-2"><label class="grid gap-1.5 text-sm font-medium">Due date<input name="due_at" type="datetime-local" class="rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-orange-500"></label><label class="grid gap-1.5 text-sm font-medium">Priority<select name="priority" class="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500"><option value="normal">Normal</option><option value="high">High</option><option value="urgent">Urgent</option><option value="low">Low</option></select></label></div><label class="grid gap-1.5 text-sm font-medium">Notes<textarea name="body" rows="3" class="rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-orange-500"></textarea></label><p data-form-error class="hidden rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700"></p><button type="submit" data-default-label="Save task" class="justify-self-start rounded-lg bg-slate-950 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-800 disabled:cursor-wait disabled:opacity-60">Save task</button></form></article>
                    </section>

                    <section class="mt-8 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
                        <div class="flex flex-wrap items-center justify-between gap-3"><div><h2 class="font-semibold">Recent activity</h2><p class="mt-1 text-sm text-slate-500">A workspace-only record of changes made in the CRM.</p></div><a href="{{ route('workspace.activity', $workspace) }}" class="text-sm font-medium text-orange-600 hover:text-orange-700">View history</a></div>
                        <div class="mt-5 grid divide-y divide-slate-100">
                            @forelse ($auditEvents as $auditEvent)
                                <div class="flex items-center justify-between gap-4 py-3 first:pt-0 last:pb-0"><p class="text-sm"><span class="font-medium">{{ $auditEvent->actor?->name ?? 'System' }}</span> {{ str($auditEvent->action)->replace('.', ' ')->lower() }}</p><time class="shrink-0 text-xs text-slate-400" datetime="{{ $auditEvent->occurred_at?->toAtomString() }}">{{ $auditEvent->occurred_at?->diffForHumans() }}</time></div>
                            @empty
                                <p class="py-5 text-sm text-slate-500">Workspace activity will appear here as your team works.</p>
                            @endforelse
                        </div>
                    </section>
                @endif
            </main>
        </div>
    </body>
</html>
