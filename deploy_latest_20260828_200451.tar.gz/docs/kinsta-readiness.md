# Kinsta readiness

This is a standalone Laravel application. It is not a WordPress plugin or theme. The deployable application root is `backend`; the public web root must point to `backend/public`.

## Live status (2026-08-28)

**Deployed and reachable at `https://sojourncrm.kinsta.cloud`.** `/login` renders, `/up` returns 200,
`/` redirects unauthenticated visitors to `/login`. Verified by an independent test run against the
real provisioned MySQL/MariaDB database on that box: **27 tests passed, 103 assertions, 0 failures.**

Real environment layout differs from a normal Laravel deploy and from what this doc originally
assumed — **read this before touching that box again**:

- Kinsta's web root on this site is **fixed** at `/www/sojourncrm_314/public` and cannot be changed
  via MyKinsta. `open_basedir` on the PHP-FPM pool is locked to that path (plus a couple of reserved,
  currently-empty paths: `mysqleditor`, `web`, `deploy`, `deployment`, `deployments`) — the app's own
  code directory is **not** inside that sandbox by default.
- Fix: app code lives at `/www/sojourncrm_314/private/app` (not a sibling `app/` at the site root —
  Kinsta support could not widen `open_basedir` to the whole site or to a top-level `app/`, only to a
  path under `private/`). Kinsta support added `/www/sojourncrm_314/private/app` to `open_basedir` on
  request — ask for that exact path if this ever needs rebuilding.
- `public/index.php`'s three `require`/`file_exists` paths were hand-edited to point at
  `../private/app/...` instead of the Laravel-default `../...`, since `public/` is no longer a
  subdirectory of the app root.
- **After moving the app directory, `php artisan optimize:clear` + `php artisan optimize` were not
  enough on their own** — the fix landed, but the site kept 500ing for a short window afterward. That
  was PHP's `realpath_cache` (default TTL ~120s) still resolving the old pre-move location; it cleared
  itself without further action. If this reappears in a future move, don't chase phantom cache bugs —
  wait past the TTL or ask Kinsta to restart PHP again before assuming the code is wrong.
- `.env` on the box is real (MySQL credentials, `APP_ENV=production`, `APP_DEBUG=false`,
  `APP_URL=https://sojourncrm.kinsta.cloud`), not the placeholder committed here.

## Verified locally

- Laravel 13 application with PHP 8.3 or newer required.
- Production frontend assets compile with `npm run build`.
- Database migrations and synthetic seed data run successfully on local SQLite.
- Full feature suite passes locally.
- No production credentials, HubSpot credentials, OAuth credentials, or customer data are stored in the repository.

## Required before a first Kinsta deployment

1. Create the application and a production MySQL database, then provide only the connection values through Kinsta's secret/environment configuration. The app's PHP runtime has `pdo_mysql`; it does not require a Postgres service.
2. Set `APP_ENV=production`, `APP_DEBUG=false`, a unique `APP_KEY`, and the final HTTPS `APP_URL`.
3. Set `DB_CONNECTION=mysql` with the supplied host, port, database, username, and password. Use MySQL 8 (or another Kinsta-supported version with native JSON column support).
4. Use database-backed sessions, cache, and queues unless a managed alternative is deliberately selected:
   - `SESSION_DRIVER=database`
   - `CACHE_STORE=database`
   - `QUEUE_CONNECTION=database`
5. Install PHP dependencies without development packages, compile assets, run migrations, then cache Laravel configuration, routes, and views.
6. Ensure `storage` and `bootstrap/cache` are writable by the runtime user.
7. Configure a long-running queue worker if queued work is enabled, and configure Laravel's scheduler only when scheduled jobs are added.
8. Register the exact production callback URLs for Microsoft and Google before enabling sign-in. Do not turn on either sign-in button until their credentials are present in the application environment.

## Database compatibility

The migrations use Laravel's portable schema builder: InnoDB foreign keys, decimal and timestamp columns, indexed strings, and native JSON columns. They do not use Postgres-only syntax such as `jsonb`, Postgres arrays, custom types, or Postgres-specific functions. MySQL's native `JSON` type is required for workspace settings, record properties, attribution, activity metadata, OAuth profiles, and audit snapshots.

Postgres remains a possible future target if a separate database service is provisioned and the app runtime has `pdo_pgsql`, but it is not the correct default for this Kinsta app.

## Commands for the deployment process

Run these from `backend` only after the runtime and environment values exist:

```bash
composer install --no-dev --prefer-dist --optimize-autoloader
npm ci
npm run build
php artisan migrate --force
php artisan optimize
```

Before applying the migration on Kinsta, perform a no-write preflight from `backend`:

```bash
php artisan about
php artisan migrate --pretend
```

Confirm the output reports the MySQL connection and that the generated statements complete without an error. Only then run `php artisan migrate --force`.

Run `php artisan db:seed --force` only when intentionally loading synthetic data into a non-production environment. It must not be part of the production deployment command.

## Items deliberately not prepared yet

- Actual Kinsta account/app configuration or server access.
- Production database credentials.
- Microsoft Entra ID and Google OAuth registrations.
- HubSpot data migration or live HubSpot access.
- Domain/DNS cutover and callback URLs.

These require the real environment and should be handled once the hosting target and credentials are available.
