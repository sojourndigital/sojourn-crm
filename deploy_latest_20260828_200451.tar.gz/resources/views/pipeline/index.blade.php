@include('partials.list-controls')
@include('partials.pipeline-views')
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <title>Pipeline · Sojourn CRM</title>
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    </head>
    <body class="min-h-screen bg-slate-100 text-slate-900 antialiased"><div class="min-h-screen lg:grid lg:grid-cols-[15rem_1fr]">@include('partials.sidebar', ['workspace' => $workspace])
        <main class="mx-auto max-w-[110rem] px-6 py-8 sm:px-10">
            <header class="flex flex-wrap items-center justify-between gap-4"><div><a href="{{ route('workspaces.dashboard', $workspace) }}" class="text-sm font-medium text-orange-600 hover:text-orange-700">← {{ $workspace->name }}</a><h1 class="mt-2 text-3xl font-semibold tracking-tight">Pipeline</h1><p class="mt-1 text-sm text-slate-500">Move opportunities through the sales process.</p></div><a href="{{ route('workspaces.dashboard', $workspace) }}#new-deal" class="rounded-lg bg-orange-500 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-600">Add deal</a></header>

            <section class="mt-8 overflow-x-auto pb-4"><div class="grid min-w-[90rem] grid-cols-6 gap-4">@foreach ($stages as $key => $label)<article class="rounded-2xl bg-slate-200/70 p-3"><div class="flex items-center justify-between gap-3"><h2 class="text-sm font-semibold">{{ $label }}</h2><span class="rounded-full bg-white px-2 py-1 text-xs font-medium text-slate-500">{{ ($dealsByStage[$key] ?? collect())->count() }}</span></div><div class="mt-3 grid gap-3">@forelse ($dealsByStage[$key] ?? [] as $deal)<div class="rounded-xl bg-white p-4 shadow-sm"><p class="text-sm font-semibold text-slate-800">{{ $deal->name }}</p><p class="mt-1 text-xs text-slate-500">{{ $deal->company?->name ?? trim($deal->contact?->first_name.' '.$deal->contact?->last_name) ?: 'Unassigned' }}</p><div class="mt-4 flex items-center justify-between gap-3"><p class="text-sm font-semibold">{{ $deal->currency }} {{ number_format((float) $deal->amount, 0) }}</p><select data-deal-stage="{{ route('deals.update', [$workspace, $deal]) }}" class="max-w-28 rounded-lg border border-slate-200 bg-white px-2 py-1 text-xs font-medium text-slate-600 outline-none focus:border-orange-500">@foreach ($stages as $stageKey => $stageLabel)<option value="{{ $stageKey }}" @selected($deal->stage === $stageKey)>{{ $stageLabel }}</option>@endforeach</select></div></div>@empty<p class="rounded-xl border border-dashed border-slate-300 px-3 py-5 text-center text-xs text-slate-500">No deals</p>@endforelse</div></article>@endforeach</div></section>
        </main></div>
    </body>
</html>
