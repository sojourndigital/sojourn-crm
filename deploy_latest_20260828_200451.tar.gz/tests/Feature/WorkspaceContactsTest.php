<?php

namespace Tests\Feature;

use App\Models\Contact;
use App\Models\Membership;
use App\Models\Task;
use App\Models\User;
use App\Models\Workspace;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class WorkspaceContactsTest extends TestCase
{
    use RefreshDatabase;

    public function test_member_can_search_only_contacts_in_their_workspace(): void
    {
        $user = User::factory()->create();
        $workspace = Workspace::factory()->create(['name' => 'North Workspace']);
        Membership::factory()->create(['user_id' => $user->id, 'workspace_id' => $workspace->id]);
        Contact::factory()->create(['workspace_id' => $workspace->id, 'first_name' => 'Avery', 'last_name' => 'Reed', 'email' => 'avery@example.test']);
        Contact::factory()->create(['workspace_id' => $workspace->id, 'first_name' => 'Morgan', 'last_name' => 'Sloan']);
        Contact::factory()->create(['first_name' => 'Avery', 'last_name' => 'Other Workspace']);

        $response = $this->actingAs($user)->get(route('workspace.contacts', [$workspace, 'q' => 'avery']));

        $response->assertOk();
        $response->assertSee('Avery Reed');
        $response->assertDontSee('Morgan Sloan');
        $response->assertDontSee('Avery Other Workspace');
    }

    public function test_member_cannot_open_another_workspaces_contacts(): void
    {
        $user = User::factory()->create();
        $workspace = Workspace::factory()->create();
        $otherWorkspace = Workspace::factory()->create();
        Membership::factory()->create(['user_id' => $user->id, 'workspace_id' => $workspace->id]);

        $this->actingAs($user)
            ->get(route('workspace.contacts', $otherWorkspace))
            ->assertNotFound();
    }

    public function test_member_can_open_a_contact_detail_page_with_related_work(): void
    {
        [$user, $workspace] = $this->memberWithWorkspace();
        $contact = Contact::factory()->create(['workspace_id' => $workspace->id, 'first_name' => 'Avery', 'last_name' => 'Reed']);
        Task::factory()->create(['workspace_id' => $workspace->id, 'subject_type' => Contact::class, 'subject_id' => $contact->id, 'title' => 'Follow up with Avery']);

        $this->actingAs($user)
            ->get(route('workspace.contact', [$workspace, $contact]))
            ->assertOk()
            ->assertSee('Avery Reed')
            ->assertSee('Follow up with Avery');
    }

    /** @return array{User, Workspace} */
    private function memberWithWorkspace(): array
    {
        $user = User::factory()->create();
        $workspace = Workspace::factory()->create();
        Membership::factory()->create(['user_id' => $user->id, 'workspace_id' => $workspace->id]);

        return [$user, $workspace];
    }
}
