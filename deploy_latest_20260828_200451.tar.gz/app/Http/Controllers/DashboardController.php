<?php

namespace App\Http\Controllers;

use App\Models\AuditEvent;
use App\Models\Contact;
use App\Models\Deal;
use App\Models\Task;
use App\Models\Workspace;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Carbon;

class DashboardController extends Controller
{
    public function index(Request $request): View
    {
        $workspaces = $request->user()->workspaces()->orderBy('name')->get();

        return $this->showWorkspace($workspaces->first(), $workspaces);
    }

    public function show(Request $request, Workspace $workspace): View
    {
        abort_unless($request->user()->workspaces()->whereKey($workspace)->exists(), 404);

        $workspaces = $request->user()->workspaces()->orderBy('name')->get();

        return $this->showWorkspace($workspace, $workspaces);
    }

    /**
     * @param  Collection<int, Workspace>  $workspaces
     */
    private function showWorkspace(?Workspace $workspace, Collection $workspaces): View
    {
        if ($workspace === null) {
            return view('dashboard', [
                'workspace' => null,
                'workspaces' => $workspaces,
                'stats' => [],
                'dealsByStage' => collect(),
                'deals' => collect(),
                'contacts' => collect(),
                'tasks' => collect(),
                'auditEvents' => collect(),
            ]);
        }

        return view('dashboard', [
            'workspace' => $workspace,
            'workspaces' => $workspaces,
            'stats' => [
                'open_deals' => Deal::query()->whereBelongsTo($workspace)->whereNotIn('stage', ['closed_won', 'closed_lost'])->count(),
                'pipeline_value' => Deal::query()->whereBelongsTo($workspace)->whereNotIn('stage', ['closed_won', 'closed_lost'])->sum('amount'),
                'tasks_due_today' => Task::query()->whereBelongsTo($workspace)->where('status', 'open')->whereDate('due_at', Carbon::today())->count(),
                'tasks_overdue' => Task::query()->whereBelongsTo($workspace)->where('status', 'open')->whereNotNull('due_at')->where('due_at', '<', Carbon::now())->count(),
            ],
            'dealsByStage' => Deal::query()
                ->whereBelongsTo($workspace)
                ->selectRaw('stage, count(*) as deal_count, coalesce(sum(amount), 0) as total_amount')
                ->groupBy('stage')
                ->orderByRaw("case stage when 'new' then 1 when 'qualified' then 2 when 'proposal' then 3 when 'negotiation' then 4 when 'closed_won' then 5 when 'closed_lost' then 6 else 7 end")
                ->get(),
            'deals' => Deal::query()
                ->whereBelongsTo($workspace)
                ->whereNotIn('stage', ['closed_won', 'closed_lost'])
                ->with(['company', 'contact'])
                ->orderByDesc('amount')
                ->orderByDesc('id')
                ->limit(6)
                ->get(),
            'contacts' => Contact::query()
                ->whereBelongsTo($workspace)
                ->with('company')
                ->orderByDesc('created_at')
                ->orderByDesc('id')
                ->limit(6)
                ->get(),
            'tasks' => Task::query()
                ->whereBelongsTo($workspace)
                ->where('status', 'open')
                ->with(['assignedUser', 'subject'])
                ->orderByRaw('case when due_at is null then 1 else 0 end')
                ->orderBy('due_at')
                ->orderBy('id')
                ->limit(6)
                ->get(),
            'auditEvents' => AuditEvent::query()
                ->whereBelongsTo($workspace)
                ->with('actor:id,name')
                ->orderByDesc('occurred_at')
                ->orderByDesc('id')
                ->limit(8)
                ->get(),
        ]);
    }
}
