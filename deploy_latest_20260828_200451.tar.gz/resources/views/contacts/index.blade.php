@include('partials.list-controls')
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Contacts · Sojourn CRM</title>
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    </head>
    <body class="min-h-screen bg-slate-100 text-slate-900 antialiased">
        <div class="min-h-screen lg:grid lg:grid-cols-[15rem_1fr]">
            @include('partials.sidebar', ['workspace' => $workspace])
        <main class="mx-auto max-w-7xl px-6 py-8 sm:px-10">
            <header class="flex flex-wrap items-center justify-between gap-4">
                <div><a href="{{ route('workspaces.dashboard', $workspace) }}" class="text-sm font-medium text-orange-600 hover:text-orange-700">← {{ $workspace->name }}</a><h1 class="mt-2 text-3xl font-semibold tracking-tight">Contacts</h1><p class="mt-1 text-sm text-slate-500">All relationship records in this workspace.</p></div>
                <a href="{{ route('workspaces.dashboard', $workspace) }}#new-contact" class="rounded-lg bg-orange-500 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-600">Add contact</a>
            </header>

            <form method="GET" class="mt-8 flex flex-wrap gap-3"><label class="sr-only" for="contact-search">Search contacts</label><input id="contact-search" name="q" value="{{ $search }}" type="search" placeholder="Search name, email, or phone" class="w-full max-w-md rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm outline-none focus:border-orange-500"><button type="submit" class="rounded-lg bg-slate-950 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-800">Search</button>@if ($search !== '')<a href="{{ route('workspace.contacts', $workspace) }}" class="rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50">Clear</a>@endif</form>

            <section class="mt-6 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                <div class="overflow-x-auto"><table class="w-full min-w-[46rem] text-left text-sm"><thead class="border-b border-slate-100 bg-slate-50 text-xs tracking-wide text-slate-500 uppercase"><tr><th class="px-5 py-3 font-medium">Contact</th><th class="px-5 py-3 font-medium">Company</th><th class="px-5 py-3 font-medium">Stage</th><th class="px-5 py-3 font-medium">Phone</th><th class="px-5 py-3 font-medium">Added</th></tr></thead><tbody class="divide-y divide-slate-100">@forelse ($contacts as $contact)<tr><td class="px-5 py-4"><a href="{{ route('workspace.contact', [$workspace, $contact]) }}" class="font-medium text-slate-800 hover:text-orange-600">{{ $contact->first_name }} {{ $contact->last_name }}</a><p class="mt-1 text-xs text-slate-500">{{ $contact->email ?? 'No email' }}</p></td><td class="px-5 py-4 text-slate-600">{{ $contact->company?->name ?? '—' }}</td><td class="px-5 py-4"><span class="rounded-full bg-orange-50 px-2.5 py-1 text-xs font-medium text-orange-700">{{ str($contact->lifecycle_stage)->replace('_', ' ')->title() }}</span></td><td class="px-5 py-4 text-slate-600">{{ $contact->phone ?? '—' }}</td><td class="px-5 py-4 text-slate-500">{{ $contact->created_at->format('M j, Y') }}</td></tr>@empty<tr><td colspan="5" class="px-5 py-12 text-center text-slate-500">No contacts match this search.</td></tr>@endforelse</tbody></table></div>
                @if ($contacts->hasPages())<div class="border-t border-slate-100 px-5 py-4">{{ $contacts->links() }}</div>@endif
            </section>
        </main>
        </div>
    </body>
</html>
