<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <title>Tasks · Sojourn CRM</title>
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    </head>
    <body class="min-h-screen bg-slate-100 text-slate-900 antialiased">
        <div class="min-h-screen lg:grid lg:grid-cols-[15rem_1fr]">
            @include('partials.sidebar', ['workspace' => $workspace])
        <main class="mx-auto max-w-5xl px-6 py-8 sm:px-10">
            <header class="flex flex-wrap items-center justify-between gap-4"><div><a href="{{ route('workspaces.dashboard', $workspace) }}" class="text-sm font-medium text-orange-600 hover:text-orange-700">← {{ $workspace->name }}</a><h1 class="mt-2 text-3xl font-semibold tracking-tight">Task queue</h1><p class="mt-1 text-sm text-slate-500">Open tasks, ordered by due date.</p></div><a href="{{ route('workspaces.dashboard', $workspace) }}#new-task" class="rounded-lg bg-orange-500 px-4 py-2 text-sm font-semibold text-white hover:bg-orange-600">Add task</a></header>

            <section class="mt-8 grid gap-3">@forelse ($tasks as $task)<article class="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><div class="min-w-0"><div class="flex flex-wrap items-center gap-2"><h2 class="font-semibold">{{ $task->title }}</h2><span class="rounded-full px-2 py-1 text-xs font-medium {{ match($task->priority) { 'urgent' => 'bg-red-50 text-red-700', 'high' => 'bg-orange-50 text-orange-700', 'low' => 'bg-slate-100 text-slate-500', default => 'bg-blue-50 text-blue-700' } }}">{{ str($task->priority)->title() }}</span>@if ($task->due_at?->isPast())<span class="rounded-full bg-red-50 px-2 py-1 text-xs font-medium text-red-700">Overdue</span>@endif</div>@if ($task->body)<p class="mt-2 max-w-2xl text-sm text-slate-600">{{ $task->body }}</p>@endif<p class="mt-2 text-xs text-slate-500">{{ $task->assignedUser?->name ?? 'Unassigned' }} · {{ $task->due_at?->format('M j, Y g:i A') ?? 'No due date' }}</p></div><button type="button" data-complete-task="{{ route('tasks.update', [$workspace, $task]) }}" class="rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm font-semibold text-slate-700 hover:border-orange-500 hover:text-orange-700 disabled:cursor-wait disabled:opacity-60">Complete</button></article>@empty<article class="rounded-2xl border border-dashed border-slate-300 bg-white px-6 py-16 text-center"><h2 class="font-semibold">Nothing open right now</h2><p class="mt-2 text-sm text-slate-500">New tasks will appear here when they are added.</p></article>@endforelse</section>
            @if ($tasks->hasPages())<div class="mt-6">{{ $tasks->links() }}</div>@endif
        </main>
        </div>
    </body>
</html>
