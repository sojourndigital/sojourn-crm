<?php

namespace App\Http\Requests;

use App\Models\Company;
use App\Models\Contact;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateDealRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'company_id' => ['sometimes', 'nullable', Rule::exists(Company::class, 'id')->where('workspace_id', $this->route('workspace')->id)],
            'contact_id' => ['sometimes', 'nullable', Rule::exists(Contact::class, 'id')->where('workspace_id', $this->route('workspace')->id)],
            'name' => ['sometimes', 'required', 'string', 'max:255'],
            'pipeline' => ['sometimes', 'nullable', 'string', 'max:100'],
            'stage' => ['sometimes', 'nullable', Rule::in(['new', 'qualified', 'proposal', 'negotiation', 'closed_won', 'closed_lost'])],
            'amount' => ['sometimes', 'nullable', 'numeric', 'min:0', 'max:999999999999.99'],
            'currency' => ['sometimes', 'nullable', 'string', 'size:3'],
            'probability' => ['sometimes', 'nullable', 'integer', 'between:0,100'],
            'expected_close_at' => ['sometimes', 'nullable', 'date'],
            'closed_at' => ['sometimes', 'nullable', 'date'],
            'properties' => ['sometimes', 'nullable', 'array'],
        ];
    }
}
