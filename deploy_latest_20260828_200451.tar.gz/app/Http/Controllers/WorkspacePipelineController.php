<?php

namespace App\Http\Controllers;

use App\Models\Deal;
use App\Models\Workspace;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;

class WorkspacePipelineController extends Controller
{
    public function index(Request $request, Workspace $workspace): View
    {
        $stages = [
            'new' => 'New',
            'qualified' => 'Qualified',
            'proposal' => 'Proposal',
            'negotiation' => 'Negotiation',
            'closed_won' => 'Closed won',
            'closed_lost' => 'Closed lost',
        ];
        $search = $request->string('q')->trim()->substr(0, 100)->toString();
        $view = $request->string('view')->toString();

        $dealsByStage = Deal::query()
            ->whereBelongsTo($workspace)
            ->whereIn('stage', array_keys($stages))
            ->when($view === 'closing_month', fn ($query) => $query->whereNotIn('stage', ['closed_won', 'closed_lost'])->whereBetween('expected_close_at', [Carbon::now()->startOfMonth(), Carbon::now()->endOfMonth()]))
            ->when($search !== '', fn ($query) => $query->where(function ($query) use ($search): void {
                $pattern = '%'.mb_strtolower($search).'%';
                $query->whereRaw('lower(name) like ?', [$pattern]);
            }))
            ->select(['id', 'workspace_id', 'company_id', 'contact_id', 'name', 'stage', 'amount', 'currency', 'expected_close_at'])
            ->with(['company:id,name', 'contact:id,first_name,last_name'])
            ->orderByDesc('amount')
            ->get()
            ->groupBy('stage');

        return view('pipeline.index', [
            'workspace' => $workspace,
            'stages' => $stages,
            'dealsByStage' => $dealsByStage,
            'search' => $search,
            'view' => $view,
        ]);
    }

    public function show(Workspace $workspace, Deal $deal): View
    {
        $deal->load([
            'company:id,name,domain',
            'contact:id,first_name,last_name,email',
            'tasks' => fn ($query) => $query->where('status', 'open')->with('assignedUser:id,name')->orderBy('due_at')->orderBy('id'),
            'auditEvents' => fn ($query) => $query->with('actor:id,name')->latest('occurred_at')->latest('id')->limit(20),
            'activities' => fn ($query) => $query->with('actor:id,name')->latest('occurred_at')->latest('id')->limit(20),
        ]);

        return view('pipeline.show', ['workspace' => $workspace, 'deal' => $deal]);
    }
}
