<?php

namespace Database\Factories;

use App\Models\Deal;
use App\Models\Workspace;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<Deal>
 */
class DealFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'workspace_id' => Workspace::factory(),
            'company_id' => null,
            'contact_id' => null,
            'name' => fake()->catchPhrase(),
            'pipeline' => 'sales',
            'stage' => 'new',
            'amount' => fake()->randomFloat(2, 500, 10000),
            'currency' => 'CAD',
            'probability' => 25,
            'expected_close_at' => now()->addMonth(),
            'closed_at' => null,
            'properties' => [],
        ];
    }
}
