<?php

namespace Tests\Feature;

use App\Models\AuditEvent;
use App\Models\Company;
use App\Models\Contact;
use App\Models\Deal;
use App\Models\Membership;
use App\Models\Task;
use App\Models\User;
use App\Models\Workspace;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class InternalDashboardTest extends TestCase
{
    use RefreshDatabase;

    public function test_signed_in_user_sees_only_their_workspace_dashboard(): void
    {
        $user = User::factory()->create(['name' => 'Jordan Lee']);
        $workspace = Workspace::factory()->create(['name' => 'Synthetic Workspace']);
        Membership::factory()->create(['user_id' => $user->id, 'workspace_id' => $workspace->id]);
        $company = Company::factory()->create(['workspace_id' => $workspace->id, 'name' => 'Sample Company']);
        $contact = Contact::factory()->create(['workspace_id' => $workspace->id, 'company_id' => $company->id, 'first_name' => 'Avery', 'last_name' => 'Reed']);
        Deal::factory()->create(['workspace_id' => $workspace->id, 'company_id' => $company->id, 'contact_id' => $contact->id, 'name' => 'Sample Deal', 'amount' => 12500]);
        Task::factory()->create(['workspace_id' => $workspace->id, 'assigned_user_id' => $user->id, 'title' => 'Follow up with Avery']);
        AuditEvent::factory()->create(['workspace_id' => $workspace->id, 'actor_user_id' => $user->id, 'action' => 'contact.created']);

        $response = $this->actingAs($user)->get('/');

        $response->assertOk();
        $response->assertSee('Synthetic Workspace');
        $response->assertSee('Sample Deal');
        $response->assertSee('Follow up with Avery');
        $response->assertSee('Avery Reed');
        $response->assertSee('Add contact');
        $response->assertSee('Add deal');
        $response->assertSee('Add task');
        $response->assertSee('Complete');
        $response->assertSee('Jordan Lee');
        $response->assertSee('contact created');
    }

    public function test_dashboard_requires_authentication(): void
    {
        $this->get('/')->assertRedirect(route('login'));
    }
}
