<?php

namespace Database\Seeders;

use App\Models\Activity;
use App\Models\AuditEvent;
use App\Models\Company;
use App\Models\Contact;
use App\Models\Deal;
use App\Models\IdentityProvider;
use App\Models\Membership;
use App\Models\Task;
use App\Models\User;
use App\Models\Workspace;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $administrator = User::factory()->create([
            'name' => 'Sojourn CRM Admin',
            'email' => 'admin@example.test',
        ]);

        $workspace = Workspace::factory()->create([
            'name' => 'Northstar Property Care',
            'slug' => 'northstar-property-care',
        ]);

        Membership::factory()->for($workspace)->for($administrator)->create(['role' => 'admin']);
        IdentityProvider::factory()->for($administrator)->create(['provider' => 'microsoft']);
        IdentityProvider::factory()->for($administrator)->create(['provider' => 'google']);

        $company = Company::factory()->for($workspace)->create(['name' => 'Northstar Property Care Ltd.']);
        $contact = Contact::factory()->for($workspace)->for($company)->create([
            'first_name' => 'Avery',
            'last_name' => 'Morgan',
            'source' => 'synthetic_form',
        ]);
        $deal = Deal::factory()->for($workspace)->for($company)->for($contact)->create([
            'name' => 'Seasonal service agreement',
            'stage' => 'qualified',
        ]);

        Activity::factory()->for($workspace)->for($administrator, 'actor')->for($contact, 'subject')->create([
            'body' => 'Synthetic enquiry received from the test form.',
        ]);
        Task::factory()->for($workspace)->for($administrator, 'assignedUser')->for($deal, 'subject')->create([
            'title' => 'Review synthetic enquiry',
        ]);
        AuditEvent::factory()->for($workspace)->for($administrator, 'actor')->for($deal, 'auditable')->create([
            'action' => 'seeded',
            'after' => ['stage' => 'qualified'],
        ]);
    }
}
