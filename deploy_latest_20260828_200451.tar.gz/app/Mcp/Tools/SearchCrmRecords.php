<?php

namespace App\Mcp\Tools;

use App\Models\Contact;
use App\Models\Deal;
use App\Models\Workspace;
use Illuminate\Contracts\JsonSchema\JsonSchema;
use Illuminate\JsonSchema\Types\Type;
use Laravel\Mcp\Request;
use Laravel\Mcp\Response;
use Laravel\Mcp\Server\Attributes\Description;
use Laravel\Mcp\Server\Tool;
use Laravel\Mcp\Server\Tools\Annotations\IsReadOnly;

#[Description('Search contacts and deals within one CRM workspace. Returns only read-only record summaries.')]
#[IsReadOnly]
class SearchCrmRecords extends Tool
{
    /**
     * Handle the tool request.
     */
    public function handle(Request $request): Response
    {
        $request->validate([
            'workspace' => ['required', 'string', 'exists:workspaces,slug'],
            'query' => ['nullable', 'string', 'max:100'],
            'limit' => ['nullable', 'integer', 'between:1,25'],
        ]);

        $workspace = Workspace::query()->where('slug', $request->get('workspace'))->firstOrFail();
        $query = trim((string) $request->get('query', ''));
        $limit = (int) $request->get('limit', 10);

        $contacts = Contact::query()
            ->whereBelongsTo($workspace)
            ->when($query !== '', function ($contactQuery) use ($query): void {
                $contactQuery->where(function ($searchQuery) use ($query): void {
                    $searchQuery->where('first_name', 'like', "%{$query}%")
                        ->orWhere('last_name', 'like', "%{$query}%")
                        ->orWhere('email', 'like', "%{$query}%");
                });
            })
            ->orderBy('last_name')
            ->limit($limit)
            ->get(['id', 'first_name', 'last_name', 'email', 'lifecycle_stage', 'source']);

        $deals = Deal::query()
            ->whereBelongsTo($workspace)
            ->when($query !== '', fn ($dealQuery) => $dealQuery->where('name', 'like', "%{$query}%"))
            ->latest('updated_at')
            ->limit($limit)
            ->get(['id', 'name', 'pipeline', 'stage', 'amount', 'currency', 'probability']);

        return Response::structured([
            'workspace' => ['name' => $workspace->name, 'slug' => $workspace->slug],
            'contacts' => $contacts->all(),
            'deals' => $deals->all(),
        ]);
    }

    /**
     * Get the tool's input schema.
     *
     * @return array<string, Type>
     */
    public function schema(JsonSchema $schema): array
    {
        return [
            'workspace' => $schema->string()->description('The workspace slug to search.')->required(),
            'query' => $schema->string()->description('Optional name or email search text.'),
            'limit' => $schema->integer()->description('Maximum contacts and deals per result type, from 1 to 25.'),
        ];
    }
}
