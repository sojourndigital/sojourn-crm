<?php

namespace App\Mcp\Servers;

use App\Mcp\Tools\SearchCrmRecords;
use Laravel\Mcp\Server;
use Laravel\Mcp\Server\Attributes\Instructions;
use Laravel\Mcp\Server\Attributes\Name;
use Laravel\Mcp\Server\Attributes\Version;

#[Name('Sojourn CRM Read Only')]
#[Version('0.0.1')]
#[Instructions('Use these tools only to inspect CRM records. They never create, update, delete, upload, or trigger external actions.')]
class CrmReadOnly extends Server
{
    protected array $tools = [
        SearchCrmRecords::class,
    ];

    protected array $resources = [
        //
    ];

    protected array $prompts = [
        //
    ];
}
