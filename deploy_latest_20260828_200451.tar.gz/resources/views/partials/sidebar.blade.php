<aside class="bg-slate-950 px-5 py-6 text-slate-300 lg:min-h-screen">
    <a href="{{ route('workspaces.dashboard', $workspace) }}" class="flex items-center gap-3 text-white"><span class="grid size-9 place-items-center rounded-xl bg-orange-500 text-sm font-black">S</span><span class="font-semibold tracking-tight">Sojourn CRM</span></a>
    <p class="mt-8 px-3 text-xs font-medium tracking-wide text-slate-500 uppercase">Workspace</p>
    <p class="mt-2 px-3 text-sm font-medium text-white">{{ $workspace->name }}</p>
    <nav class="mt-6 grid gap-1 text-sm" aria-label="CRM navigation">
        <a href="{{ route('workspace.contacts', $workspace) }}" class="rounded-lg px-3 py-2.5 hover:bg-white/5 hover:text-white">Contacts</a>
        <a href="{{ route('workspace.companies', $workspace) }}" class="rounded-lg px-3 py-2.5 hover:bg-white/5 hover:text-white">Companies</a>
        <a href="{{ route('workspace.pipeline', $workspace) }}" class="rounded-lg px-3 py-2.5 hover:bg-white/5 hover:text-white">Deals</a>
        <a href="{{ route('workspace.tasks', $workspace) }}" class="rounded-lg px-3 py-2.5 hover:bg-white/5 hover:text-white">Tasks</a>
        <a href="{{ route('workspace.activity', $workspace) }}" class="rounded-lg px-3 py-2.5 hover:bg-white/5 hover:text-white">Activity</a>
    </nav>
    <a href="{{ route('dashboard') }}" class="mt-8 block px-3 text-sm text-slate-500 hover:text-white">← Overview</a>
</aside>
