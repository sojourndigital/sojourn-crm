<?php

use App\Mcp\Servers\CrmReadOnly;
use Laravel\Mcp\Facades\Mcp;

Mcp::local('crm-read-only', CrmReadOnly::class);
