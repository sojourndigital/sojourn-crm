<?php

namespace Tests\Feature;

use App\Models\AuditEvent;
use App\Models\Membership;
use App\Models\User;
use App\Models\Workspace;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class WorkspaceActivityTest extends TestCase
{
    use RefreshDatabase;

    public function test_member_sees_only_activity_from_their_workspace(): void
    {
        $user = User::factory()->create(['name' => 'Jordan Lee']);
        $workspace = Workspace::factory()->create();
        Membership::factory()->create(['user_id' => $user->id, 'workspace_id' => $workspace->id]);
        AuditEvent::factory()->create(['workspace_id' => $workspace->id, 'actor_user_id' => $user->id, 'action' => 'deal.updated']);
        AuditEvent::factory()->create(['action' => 'contact.deleted']);

        $response = $this->actingAs($user)->get(route('workspace.activity', $workspace));

        $response->assertOk();
        $response->assertSee('Jordan Lee');
        $response->assertSee('deal updated');
        $response->assertDontSee('contact deleted');
    }

    public function test_member_cannot_open_another_workspaces_activity_history(): void
    {
        $user = User::factory()->create();
        $workspace = Workspace::factory()->create();
        $otherWorkspace = Workspace::factory()->create();
        Membership::factory()->create(['user_id' => $user->id, 'workspace_id' => $workspace->id]);

        $this->actingAs($user)
            ->get(route('workspace.activity', $otherWorkspace))
            ->assertNotFound();
    }
}
