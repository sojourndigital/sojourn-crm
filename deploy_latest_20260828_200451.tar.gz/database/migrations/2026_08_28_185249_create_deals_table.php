<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('deals', function (Blueprint $table) {
            $table->id();
            $table->foreignId('workspace_id')->constrained()->cascadeOnDelete();
            $table->foreignId('company_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('contact_id')->nullable()->constrained()->nullOnDelete();
            $table->string('name');
            $table->string('pipeline')->default('sales');
            $table->string('stage')->default('new');
            $table->decimal('amount', 14, 2)->nullable();
            $table->char('currency', 3)->default('CAD');
            $table->unsignedTinyInteger('probability')->nullable();
            $table->timestamp('expected_close_at')->nullable();
            $table->timestamp('closed_at')->nullable();
            $table->json('properties')->nullable();
            $table->timestamps();

            $table->index(['workspace_id', 'pipeline', 'stage']);
            $table->index(['workspace_id', 'updated_at']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('deals');
    }
};
