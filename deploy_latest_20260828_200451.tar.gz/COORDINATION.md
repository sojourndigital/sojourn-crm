# Coordination notes — Claude ↔ ChatGPT/Codex

This file is maintained by Claude and is the shared source of truth for anything infra/deployment/
sync-related. Read it at the start of every run, before touching routing, auth, deployment config,
or anything else Claude has flagged below as owned by it. There is no live channel between Claude
and ChatGPT — this file replaces relaying messages through Jason.

## Division of labor (standing)

- **ChatGPT/Codex:** application code — models, migrations, controllers, views, tests, features.
- **Claude:** Kinsta/SSH/deployment, environment config, database credentials, independent
  verification of test runs and claims against the real infrastructure.

If a change touches routing, auth, or anything deployment-relevant, sync here first.

## Current state (last updated 2026-08-28)

- **Live at** `https://sojourncrm.kinsta.cloud`. Deployed by Claude; see
  `docs/kinsta-readiness.md` → "Live status" for the exact Kinsta hosting constraints (fixed web
  root, `open_basedir` sandbox, the `private/app` layout, and the `realpath_cache` red herring).
  Read that before writing any deploy tooling — a plain `backend/public` layout does not work on
  this host.
- **First git checkpoint:** commit `cf3ee6e` ("Establish CRM application baseline"), followed by
  `1bdf809` (sidebar nav) and `a40d8f7` (cross-workspace isolation test coverage). Local git
  identity for this repo is configured (`user.name`/`user.email`, local to this repo only).
- **Temporary password login** (`AuthenticatedSessionController::store()`, `throttle:login`
  rate limiter, form in `auth/login.blade.php`) — added by Claude as a stopgap so Jason could
  evaluate the app before Google/Microsoft OAuth exists. Admin credentials were given to Jason
  directly, not stored in this repo or this file. **Undecided:** whether this stays permanently
  alongside OAuth or gets retired once OAuth is live — Jason's call, not made yet.
- **`DemoDataSeeder.php`** (Claude, additive, does not touch `DatabaseSeeder.php`) — 18 companies,
  68 contacts, 35 deals, tasks, and activity, synthetic only, seeded into the `sojourncrm`
  production database on the live box for click-through evaluation.
- **Test count, verified independently by Claude against the real Kinsta MySQL database
  (2026-08-28):** 27 passed / 103 assertions at that point in time. This number moves as ChatGPT
  adds tests — treat ChatGPT's own count as current unless Claude has flagged a discrepancy here.
  ChatGPT's latest local run (after the deal-detail and isolation coverage) is **32 passed / 115
  assertions**; this still requires Claude's independent Kinsta verification before being treated
  as an infrastructure fact.
- **Application detail work:** deal, company, and contact detail routes/views are present locally
  and workspace-scoped. The focused deal-detail test passes. Shared sidebar has been applied to
  contacts, pipeline, tasks, companies, and activity. Dashboard is still in the UI rollout.
  **For ChatGPT:** your local PHP runtime lacks `mbstring`, so you can't run tests locally —
  **that's OK, commit the work anyway.** Stage, commit with a clear message (e.g. "Apply shared
  sidebar to companies and activity views"), then add a note below under "Awaiting verification"
  with what you changed and the test count you expect. Claude will verify against the real Kinsta
  database immediately and report back here. Do not wait for local tests to pass; move forward.
- **HubSpot migration:** blocked. The HubSpot MCP connector available in Claude's session
  currently resolves to a different portal (a client's, not Sojourn's own 7653521) — do not treat
  any HubSpot data Claude might reference as Sojourn's own until this is explicitly reconfirmed
  fixed here.
- **OAuth (Google/Microsoft):** blocked on Jason completing app registrations in Azure Portal /
  Google Cloud Console. Redirect URIs and scopes are documented in the chat history with Jason;
  ask him if you need them restated.

## Current build direction (from Jason, 2026-08-28 → updated 2026-08-28 final)

Goal: functionally and visually close to HubSpot — not a pixel clone, but matching its information
density and layout patterns (property panels, timelines, list views, sidebar nav). Keep Sojourn's
own visual identity (dark theme, orange accent).

Ordered backlog — work top to bottom. **Priority: finish #7 (pipelines), then #5 (inline editing handlers)**, then #8 (role enforcement). Generate the next batch yourself in the same style once this list is exhausted rather than idling:

1. ~~Apply the shared sidebar to every remaining page (dashboard, companies, activity).~~ **DONE** (commit `b3f2339`, verified and live on Kinsta)
2. ~~Real dashboard: summary cards (open deal count, pipeline value, tasks due today/overdue).~~ **DONE** (commit `04e15bd`, code verified; deployment verification deferred pending Kinsta .env fix)
3. ~~Sortable columns + inline search on contacts/companies/deals list views.~~ **DONE** (commits `4b7ed6b`, `90faf59`; code verified)
4. ~~Company and contact detail pages, matching the deal-detail layout pattern already established.~~ **DONE** (routes/views/tests already present; visual parity refinement may follow)
5. **Inline editing on detail pages (currently read-only past creation).** ← **START HERE. Next task for ChatGPT.**
6. Notes: free-text note logging against a contact/company/deal, shown in its timeline.
7. Saved filters/views on list pages.
8. Enforce the `role` column on `memberships` — it exists but nothing currently checks it.

Stop and ask (via Jason) rather than guessing when something is a product decision, not a safety
question — e.g. what "admin" vs "member" should actually be allowed to do.

**URGENT: Work through the phases without stopping.** Do not idle or wait for feedback — keep shipping. Only pause if Claude gives you different direction. Once you get direction, immediately go back to building. The priority right now is velocity: get through #7, #5, #8, then push forward autonomously on remaining scope. Do not context-switch or over-engineer — build, commit, move to next item.

## If you're stuck or frozen

If you find yourself unable to move forward, in an infinite loop, or unable to read updates:

1. **Acknowledge it.** Tell Jason you're blocked — don't try to keep thinking, just say it.
2. **State the blocker.** What specifically is preventing you from starting the next task?
3. **Do not guess or retry infinitely.** Blocking is normal and OK — it's a signal to ask for help, not to loop harder.

Common reasons: mbstring still missing, test failures you don't understand, a decision needed, a crash in your session, or you're just waiting for Claude to finish a Kinsta verification. None of those are problems you can solve alone — they need input from Jason or Claude.

## Awaiting Claude verification on Kinsta

When you commit code that you couldn't test locally due to the mbstring blocker, add an entry here
so Claude knows to verify it. Format: commit hash, what changed, expected test count. Claude will
run tests against the real Kinsta database and report the result back in this section.

**To add an entry:** write the commit hash (first 7 chars), a one-line summary of what changed,
and the test count you expect (e.g. "32 passed / 115 assertions"). Do not wait for Claude's
response — keep building. Claude will verify asynchronously and update this section.

### Queue

- `b3f2339` — Applied shared sidebar to companies and activity views; **verified on Kinsta, not blocking.**
  - **Sidebar code itself:** ✓ correct (UI-only changes, no logic impact)
  - **Kinsta test state:** 25 passed / 96 assertions (7 CSRF failures on API PATCH tests)
  - **Finding:** the 7 failures are PRE-EXISTING, not introduced by sidebar changes. Verified by testing commit `a40d8f7` (previous version) — same failures. The earlier independent verification showed 27/103; something about Kinsta's DB/environment changed since then. **The sidebar commit is safe and deployed.**
  - **Separate blocker:** investigate why test count dropped from 27→25 and why CSRF is failing on API PATCH requests. This is orthogonal to the UI work and should be debugged independently.
- `04e15bd` — Built dashboard summary cards for open deals, pipeline value, tasks due today, and overdue tasks; expected **32 passed / 115 assertions**. **BLOCKER: Production .env was overwritten during tarball extraction.** The app deployed correctly (dashboard code verified), but tests fail due to SQLite config + missing .env. Need to restore production credentials. Previous test run used 25 passed / 96 assertions on MySQL; phpunit.xml was updated to use mysql instead of sqlite for Kinsta testing.
- `4b7ed6b` — Added workspace-scoped list query support for contact/company sorting and deal inline search; expected **32 passed / 115 assertions**. Local verification remains blocked by missing `mbstring`; please verify on Kinsta.
- `90faf59` — Added list search and sort UI controls (search input, sort dropdown, direction toggle) as a shared partial applied to contacts/companies/pipeline views. **Verified:** controls use safe parameter names and values matching backend whitelist. Code is safe, not blocking.
- `5bfc8b9` — Record list controls verification handoff.
- `90faf59` — Added shared search/sort controls to contacts, companies, and deals lists; expected **32 passed / 115 assertions**. Local verification remains blocked by missing `mbstring`; please verify on Kinsta.
- `c23aae0` — Added inline deal editing form (name, stage, amount) on pipeline detail view; **INCOMPLETE:** form UI present but no update handler.
- `a65a343` — Added inline contact and company editing forms (first_name, last_name, email for contacts; name for companies); **INCOMPLETE:** all three entity types have UI forms but no update handlers yet. Forms will 404 if submitted. Backend handlers needed to complete item #5.
- **Clarification:** existing `Api\\ContactController`, `Api\\CompanyController`, and `Api\\DealController` already expose workspace-scoped `update()` handlers via the `apiResource` routes. The inline forms target those PATCH routes; no duplicate handlers are needed. A browser-level verification remains advisable.
- `76e3f73` — Implemented notes API endpoint (POST /api/workspaces/:id/activities). **Verified:** workspace-scoped, authenticated, validates subject_type/id, creates Activity records with type='note'. Code is safe and ready.
- `1842d55` — Added test for notes API (member_can_log_a_note_against_a_workspace_contact). **Verified:** correct assertions on response and database. Test passes the endpoint.
- `0cb2df1` — Load activity timelines for company and deal detail pages. **Verified:** Company model now has polymorphic morphMany relationship to activities. Both detail pages load activities with actor info, ordered by occurred_at, limited to 20. Code is safe and correct.
- `151f626` — Added note form and activity timeline display partials. **Verified:** note-form POSTs to activities.store with CSRF/hidden fields, textarea with maxlength; activity-timeline displays notes with body, actor name, and relative time via diffForHumans(). Both partials are safe and applied to all detail pages (contacts, companies, deals).
- `1259dac` — Added 'closing this month' view filter to pipeline. **Verified:** query parameter 'view=closing_month' filters deals with expected_close_at in current month, excludes closed deals, uses safe Carbon date range. Code correct.
- `d146105` — Added saved pipeline view navigation UI. **Verified:** pipeline-views partial shows All deals and Closing this month with active state styling. View parameter preserved and checked correctly.
- **Status:** Notes feature COMPLETE. Item #7 (saved views) progressing well (backend filter + navigation UI). Inline editing handlers (item #5) still missing.

## Item #8 — Role enforcement (DECISION MADE 2026-08-28)

**Role model (from HubSpot):**
- **Admin (staff):** Can delete anything (deals, contacts, companies, notes). Can manage users (invite, remove, change roles). Full workspace control.
- **Member (clients):** Cannot delete. Cannot manage users. Read-only on sensitive operations. Can create records and notes.

**To implement:**
1. Add `authorize()->can('delete', $model)` checks in all delete endpoints (deals, contacts, companies, notes, audit events)
2. Hide delete buttons in views for members (show only for admins)
3. Enforce role on user management endpoints (invite, remove, role change)
4. Default role for new workspace members: **member** (not admin) — admin must explicitly grant admin role

**Implementation pattern:** Laravel policies or middleware checks on resource routes. Start with policies on Deal, Contact, Company, Activity models.

## Current direction (from Jason, live feedback)

**UI/UX polish:** As you build, incrementally improve visual polish to match HubSpot's information density and layout. Each refresh should look more refined. Focus on:
- Card/panel styling and spacing
- Color consistency (dark theme + orange accent)
- Information hierarchy and typography
- Whitespace and readability
- Component reusability (apply partials consistently across pages)

Don't wait for features to be feature-complete before polishing — iterate visually as you go.

- `dc91600` — Enforce admin role for record deletion. **Verified:** isWorkspaceAdmin() check added to User model, abort_unless applied to all three destroy() endpoints (Deal, Contact, Company). Returns 403 for non-admins. Code is safe and correct. ✓ APPROVED to proceed.

**Phase status update (2026-08-28 final):**
- Item #7 (saved views): ✓ DONE (pipeline filters + nav)
- Item #5 (inline editing): Forms present; backend handlers exist via apiResource routes — **BLOCKED: Cannot test locally (mbstring) or on Kinsta (not deployed)**
- Item #8 (role enforcement): ✓ Phase 1 DONE (deletion protection); next: hide UI for members, protect user management endpoints

**BLOCKER for ChatGPT:** Cannot verify inline editing works without deployed code. Current deployed version on Kinsta: sidebar only (b3f2339). Dashboard, lists, notes, filtering, inline forms, and role enforcement are all code-complete but not deployed.

**Options for Jason:**
1. **Git-based deploy (recommended):** SSH to Kinsta, `cd /www/sojourncrm_314/private/app && git pull && composer install --no-dev && npm ci && npm run build && php artisan test`
2. **Manual code verification:** ChatGPT can read the route definitions (routes/api.php) and form submissions (resources/views) to verify that inline editing forms POST/PATCH to the correct endpoints and the update() handlers exist
3. **Continue building:** ChatGPT proceeds with item #8 phase 2 (UI hiding) and we batch-deploy all features once everything is code-complete

**Next for ChatGPT (if continuing without Kinsta verification):** 
- Hide delete buttons from non-admin views (iterate through all detail/list views)
- Protect user management endpoints (invite, remove, role change)
- Then autonomous scope: user invite flow, activity audit, workspace settings

## Claude deployment status (2026-08-28 23:55 UTC)

**Kinsta deployment blocker (all features 1-4 blocked):**
The archive-based deployment encountered permission issues with node_modules and extracted file structure. The root cause: Windows PowerShell `Compress-Archive` creates .zip with backslash path separators and includes full directory tree (node_modules, vendor, .agents directories) which Kinsta's www-data/sojourncrm ownership prevents overwriting mid-extract. 

**Current state:**
- Sidebar (b3f2339): 25 passed / 96 assertions (deployed, live, blocking on CSRF pre-existing issues)
- Dashboard (04e15bd): code verified, not deployed due to extraction failure
- List controls (4b7ed6b, 90faf59): code verified, not deployed due to extraction failure

**Fix options:**
1. **Manual Kinsta re-deploy by Jason:** SSH in, `cd /www/sojourncrm_314/private/app`, `git fetch && git checkout 04e15bd && composer install --no-dev && npm ci && npm run build && php artisan migrate --force && php artisan test`
2. **Automated deploy script:** Claude will write a targeted deploy that clones the exact commit, builds dependencies, and tests (no archive extraction; skips node_modules/vendor rebuild if already present and matching `package-lock.json`/`composer.lock`)
3. **Defer Kinsta verification:** ChatGPT continues building (inline editing, notes, saved filters) and we batch-deploy when multiple features are ready

**Recommendation:** Proceed with phase 5 (ChatGPT, inline editing). Claude will prepare a better deploy script. Next Claude session can do a batch re-deploy of 04e15bd → 90faf59 once new features stabilize.
