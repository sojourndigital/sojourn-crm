<?php

namespace App\Http\Controllers;

use App\Models\Task;
use App\Models\Workspace;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

class WorkspaceTaskController extends Controller
{
    public function index(Request $request, Workspace $workspace): View
    {
        $tasks = Task::query()
            ->whereBelongsTo($workspace)
            ->where('status', 'open')
            ->select(['id', 'workspace_id', 'assigned_user_id', 'title', 'body', 'priority', 'due_at', 'created_at'])
            ->with('assignedUser:id,name')
            ->orderByRaw('case when due_at is null then 1 else 0 end')
            ->orderBy('due_at')
            ->orderBy('id')
            ->paginate(25);

        return view('tasks.index', [
            'workspace' => $workspace,
            'tasks' => $tasks,
        ]);
    }
}
