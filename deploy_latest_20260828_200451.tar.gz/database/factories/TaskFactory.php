<?php

namespace Database\Factories;

use App\Models\Task;
use App\Models\Workspace;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<Task>
 */
class TaskFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'workspace_id' => Workspace::factory(),
            'assigned_user_id' => null,
            'completed_by_user_id' => null,
            'subject_type' => null,
            'subject_id' => null,
            'title' => fake()->sentence(4),
            'body' => fake()->optional()->sentence(),
            'status' => 'open',
            'priority' => 'normal',
            'due_at' => now()->addWeek(),
            'completed_at' => null,
        ];
    }
}
