<?php

namespace App\Http\Requests;

use App\Models\Company;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreContactRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'company_id' => ['nullable', Rule::exists(Company::class, 'id')->where('workspace_id', $this->route('workspace')->id)],
            'first_name' => ['required', 'string', 'max:255'],
            'last_name' => ['nullable', 'string', 'max:255'],
            'email' => ['nullable', 'email:rfc', 'max:255'],
            'phone' => ['nullable', 'string', 'max:50'],
            'lifecycle_stage' => ['nullable', Rule::in(['lead', 'marketing_qualified', 'sales_qualified', 'customer', 'other'])],
            'source' => ['nullable', 'string', 'max:100'],
            'attribution' => ['nullable', 'array'],
            'properties' => ['nullable', 'array'],
        ];
    }
}
