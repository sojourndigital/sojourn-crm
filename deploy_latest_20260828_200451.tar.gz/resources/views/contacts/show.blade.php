@include('partials.contact-edit')
@include('partials.note-form', ['subject_type' => 'contact', 'subject_id' => $contact->id])
@include('partials.activity-timeline', ['activities' => $contact->activities])
<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>{{ $contact->first_name }} {{ $contact->last_name }} · Sojourn CRM</title>
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    </head>
    <body class="min-h-screen bg-slate-100 text-slate-900 antialiased">
        <main class="mx-auto max-w-5xl px-6 py-8 sm:px-10">
            <a href="{{ route('workspace.contacts', $workspace) }}" class="text-sm font-medium text-orange-600 hover:text-orange-700">← Contacts</a>
            <header class="mt-6 flex flex-wrap items-start justify-between gap-4">
                <div><p class="text-sm font-medium text-orange-600">{{ $workspace->name }}</p><h1 class="mt-1 text-3xl font-semibold tracking-tight">{{ $contact->first_name }} {{ $contact->last_name }}</h1><p class="mt-2 text-sm text-slate-500">{{ str($contact->lifecycle_stage)->replace('_', ' ')->title() }} · Added {{ $contact->created_at->format('M j, Y') }}</p></div>
                <span class="rounded-full bg-orange-50 px-3 py-1.5 text-sm font-medium text-orange-700">{{ str($contact->lifecycle_stage)->replace('_', ' ')->title() }}</span>
            </header>

            <section class="mt-8 grid gap-6 lg:grid-cols-[1fr_1.35fr]">
                <article class="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"><h2 class="font-semibold">Details</h2><dl class="mt-5 grid gap-4 text-sm"><div><dt class="text-xs font-medium tracking-wide text-slate-400 uppercase">Email</dt><dd class="mt-1 text-slate-700">{{ $contact->email ?? '—' }}</dd></div><div><dt class="text-xs font-medium tracking-wide text-slate-400 uppercase">Phone</dt><dd class="mt-1 text-slate-700">{{ $contact->phone ?? '—' }}</dd></div><div><dt class="text-xs font-medium tracking-wide text-slate-400 uppercase">Company</dt><dd class="mt-1 text-slate-700">{{ $contact->company?->name ?? '—' }}</dd></div></dl></article>
                <article class="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"><h2 class="font-semibold">Open tasks</h2><div class="mt-5 grid gap-3">@forelse ($contact->tasks as $task)<div class="rounded-xl bg-slate-50 px-4 py-3"><p class="text-sm font-medium">{{ $task->title }}</p><p class="mt-1 text-xs text-slate-500">{{ $task->assignedUser?->name ?? 'Unassigned' }} · {{ $task->due_at?->format('M j, Y') ?? 'No due date' }}</p></div>@empty<p class="text-sm text-slate-500">No open tasks for this contact.</p>@endforelse</div></article>
            </section>

            <section class="mt-6 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"><h2 class="font-semibold">Activity</h2><div class="mt-5 grid divide-y divide-slate-100">@forelse ($contact->activities as $activity)<div class="py-3 first:pt-0 last:pb-0"><div class="flex items-center justify-between gap-4"><p class="text-sm font-medium text-slate-700">{{ str($activity->type)->replace('_', ' ')->title() }}</p><time class="shrink-0 text-xs text-slate-400" datetime="{{ $activity->occurred_at?->toAtomString() }}">{{ $activity->occurred_at?->diffForHumans() }}</time></div>@if ($activity->body)<p class="mt-1 text-sm text-slate-600">{{ $activity->body }}</p>@endif<p class="mt-1 text-xs text-slate-400">{{ $activity->actor?->name ?? 'System' }}</p></div>@empty<p class="text-sm text-slate-500">No activity recorded for this contact.</p>@endforelse</div></section>
        </main>
    </body>
</html>
