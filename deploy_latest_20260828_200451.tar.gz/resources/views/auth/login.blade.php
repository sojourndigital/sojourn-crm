<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Sign in · Sojourn CRM</title>
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    </head>
    <body class="min-h-screen bg-slate-950 text-slate-100 antialiased">
        <main class="mx-auto flex min-h-screen max-w-md items-center px-6 py-12">
            <section class="w-full rounded-3xl border border-white/10 bg-white/5 p-8 shadow-2xl shadow-black/30 backdrop-blur">
                <div class="mb-8">
                    <p class="text-sm font-semibold tracking-[0.2em] text-orange-400 uppercase">Sojourn</p>
                    <h1 class="mt-3 text-3xl font-semibold tracking-tight text-white">CRM</h1>
                    <p class="mt-3 text-sm leading-6 text-slate-400">Internal access for the Sojourn team.</p>
                </div>

                @if (session('status'))
                    <p class="mb-5 rounded-xl border border-orange-400/20 bg-orange-400/10 px-4 py-3 text-sm text-orange-100">{{ session('status') }}</p>
                @endif

                <form method="POST" action="{{ route('login.store') }}" class="mb-6 grid gap-3">
                    @csrf
                    <input type="email" name="email" placeholder="Email" required
                        class="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder:text-slate-500 focus:outline-2 focus:outline-offset-2 focus:outline-orange-400">
                    <input type="password" name="password" placeholder="Password" required
                        class="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder:text-slate-500 focus:outline-2 focus:outline-offset-2 focus:outline-orange-400">
                    <button type="submit"
                        class="rounded-xl bg-orange-500 px-4 py-3 text-sm font-semibold text-white transition hover:bg-orange-400 focus:outline-2 focus:outline-offset-2 focus:outline-orange-400">
                        Sign in
                    </button>
                </form>

                <div class="grid gap-3">
                    @foreach ($providers as $provider => $configured)
                        @if ($configured)
                            <a href="{{ route('oauth.redirect', $provider) }}" class="flex items-center justify-center gap-3 rounded-xl bg-white px-4 py-3 text-sm font-semibold text-slate-900 transition hover:bg-slate-100 focus:outline-2 focus:outline-offset-2 focus:outline-orange-400">
                                Continue with {{ $provider === 'microsoft' ? 'Microsoft' : 'Google' }}
                            </a>
                        @else
                            <span class="flex cursor-not-allowed items-center justify-center gap-3 rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-medium text-slate-500">
                                {{ $provider === 'microsoft' ? 'Microsoft' : 'Google' }} sign-in is coming soon
                            </span>
                        @endif
                    @endforeach
                </div>

                <p class="mt-7 text-center text-xs leading-5 text-slate-500">Your account must be provisioned before you can sign in.</p>
            </section>
        </main>
    </body>
</html>
