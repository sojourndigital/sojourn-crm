<?php

namespace App\Http\Controllers;

use App\Models\Contact;
use App\Models\Workspace;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

class WorkspaceContactController extends Controller
{
    public function index(Request $request, Workspace $workspace): View
    {
        $search = $request->string('q')->trim()->substr(0, 100)->toString();

        $sort = $request->string('sort')->toString();
        $direction = $request->string('direction')->lower()->toString() === 'desc' ? 'desc' : 'asc';
        $sortColumn = ['name' => 'last_name', 'email' => 'email', 'created' => 'created_at'][$sort] ?? 'last_name';
        $contacts = Contact::query()
            ->whereBelongsTo($workspace)
            ->select(['id', 'workspace_id', 'company_id', 'first_name', 'last_name', 'email', 'phone', 'lifecycle_stage', 'created_at'])
            ->with('company:id,name')
            ->when($search !== '', function ($query) use ($search): void {
                $pattern = '%'.mb_strtolower($search).'%';

                $query->where(function ($query) use ($pattern): void {
                    $query->whereRaw('lower(first_name) like ?', [$pattern])
                        ->orWhereRaw('lower(last_name) like ?', [$pattern])
                        ->orWhereRaw('lower(email) like ?', [$pattern])
                        ->orWhereRaw('lower(phone) like ?', [$pattern]);
                });
            })
            ->orderBy($sortColumn, $direction)
            ->when($sortColumn === 'last_name', fn ($query) => $query->orderBy('first_name'))
            ->orderBy('id')
            ->paginate(25)
            ->withQueryString();

        return view('contacts.index', [
            'workspace' => $workspace,
            'contacts' => $contacts,
            'search' => $search,
            'sort' => $sort,
            'direction' => $direction,
        ]);
    }

    public function show(Workspace $workspace, Contact $contact): View
    {
        $contact->load([
            'company:id,name,domain,phone',
            'tasks' => fn ($query) => $query->where('status', 'open')->with('assignedUser:id,name')->orderBy('due_at')->orderBy('id'),
            'activities' => fn ($query) => $query->with('actor:id,name')->latest('occurred_at')->latest('id')->limit(20),
        ]);

        return view('contacts.show', [
            'workspace' => $workspace,
            'contact' => $contact,
        ]);
    }
}
