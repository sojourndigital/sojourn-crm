<?php

namespace App\Http\Controllers;

use App\Models\AuditEvent;
use App\Models\Workspace;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

class WorkspaceActivityController extends Controller
{
    public function index(Request $request, Workspace $workspace): View
    {
        $events = AuditEvent::query()
            ->whereBelongsTo($workspace)
            ->select(['id', 'workspace_id', 'actor_user_id', 'auditable_type', 'auditable_id', 'action', 'source', 'occurred_at'])
            ->with('actor:id,name')
            ->orderByDesc('occurred_at')
            ->orderByDesc('id')
            ->paginate(50);

        return view('activity.index', [
            'workspace' => $workspace,
            'events' => $events,
        ]);
    }
}
