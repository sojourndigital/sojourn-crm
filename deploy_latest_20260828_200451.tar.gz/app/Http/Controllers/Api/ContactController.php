<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreContactRequest;
use App\Http\Requests\UpdateContactRequest;
use App\Models\Contact;
use App\Models\Workspace;
use App\Services\AuditLogger;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class ContactController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Workspace $workspace): JsonResponse
    {
        return response()->json($workspace->contacts()->with('company')->orderByDesc('created_at')->orderByDesc('id')->paginate(25));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreContactRequest $request, Workspace $workspace, AuditLogger $auditLogger): JsonResponse
    {
        $contact = DB::transaction(function () use ($workspace, $request, $auditLogger): Contact {
            $contact = $workspace->contacts()->create($request->validated());
            $auditLogger->record($contact, $workspace, $request->user(), 'contact.created');

            return $contact;
        });

        return response()->json($contact->load('company'), 201);
    }

    /**
     * Display the specified resource.
     */
    public function show(Workspace $workspace, Contact $contact): JsonResponse
    {
        return response()->json($contact->load(['company', 'tasks']));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateContactRequest $request, Workspace $workspace, Contact $contact, AuditLogger $auditLogger): JsonResponse
    {
        DB::transaction(function () use ($contact, $workspace, $request, $auditLogger): void {
            $before = $contact->getOriginal();
            $contact->update($request->validated());
            $auditLogger->record($contact, $workspace, $request->user(), 'contact.updated', $before);
        });

        return response()->json($contact->refresh()->load('company'));
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Workspace $workspace, Contact $contact, AuditLogger $auditLogger): JsonResponse
    {
        abort_unless(request()->user()->isWorkspaceAdmin($workspace), 403);
        DB::transaction(function () use ($contact, $workspace, $auditLogger): void {
            $before = $contact->getAttributes();
            $contact->delete();
            $auditLogger->record($contact, $workspace, request()->user(), 'contact.deleted', $before);
        });

        return response()->json(status: 204);
    }
}
