<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreDealRequest;
use App\Http\Requests\UpdateDealRequest;
use App\Models\Deal;
use App\Models\Workspace;
use App\Services\AuditLogger;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class DealController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Workspace $workspace): JsonResponse
    {
        return response()->json($workspace->deals()->with(['company', 'contact'])->orderByDesc('created_at')->orderByDesc('id')->paginate(25));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreDealRequest $request, Workspace $workspace, AuditLogger $auditLogger): JsonResponse
    {
        $attributes = $this->withClosedAt($request->validated());

        $deal = DB::transaction(function () use ($workspace, $attributes, $request, $auditLogger): Deal {
            $deal = $workspace->deals()->create($attributes);
            $auditLogger->record($deal, $workspace, $request->user(), 'deal.created');

            return $deal;
        });

        return response()->json($deal->load(['company', 'contact']), 201);
    }

    /**
     * Display the specified resource.
     */
    public function show(Workspace $workspace, Deal $deal): JsonResponse
    {
        return response()->json($deal->load(['company', 'contact', 'tasks']));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateDealRequest $request, Workspace $workspace, Deal $deal, AuditLogger $auditLogger): JsonResponse
    {
        $attributes = $this->withClosedAt($request->validated(), $deal->stage);

        DB::transaction(function () use ($deal, $workspace, $request, $attributes, $auditLogger): void {
            $before = $deal->getOriginal();
            $deal->update($attributes);
            $auditLogger->record($deal, $workspace, $request->user(), 'deal.updated', $before);
        });

        return response()->json($deal->refresh()->load(['company', 'contact']));
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Workspace $workspace, Deal $deal, AuditLogger $auditLogger): JsonResponse
    {
        abort_unless(request()->user()->isWorkspaceAdmin($workspace), 403);
        DB::transaction(function () use ($deal, $workspace, $auditLogger): void {
            $before = $deal->getAttributes();
            $deal->delete();
            $auditLogger->record($deal, $workspace, request()->user(), 'deal.deleted', $before);
        });

        return response()->json(status: 204);
    }

    /**
     * @param  array<string, mixed>  $attributes
     * @return array<string, mixed>
     */
    private function withClosedAt(array $attributes, ?string $currentStage = null): array
    {
        $stage = $attributes['stage'] ?? $currentStage;

        if (in_array($stage, ['closed_won', 'closed_lost'], true)) {
            $attributes['closed_at'] ??= now();
        } elseif ($currentStage !== null && in_array($currentStage, ['closed_won', 'closed_lost'], true)) {
            $attributes['closed_at'] = null;
        }

        return $attributes;
    }
}
