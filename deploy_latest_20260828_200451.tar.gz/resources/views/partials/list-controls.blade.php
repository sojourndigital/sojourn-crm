<form method="GET" class="mx-auto flex max-w-7xl flex-wrap items-center gap-2 border-b border-slate-200 bg-slate-50 px-6 py-3 text-sm sm:px-10">
    <label class="sr-only" for="list-search">Search</label>
    <input id="list-search" name="q" value="{{ $search ?? '' }}" type="search" placeholder="Search records…" class="w-full max-w-sm rounded-lg border border-slate-300 bg-white px-3 py-2 outline-none focus:border-orange-500">
    <select name="sort" class="rounded-lg border border-slate-300 bg-white px-3 py-2" aria-label="Sort records">
        <option value="name" @selected(($sort ?? '') === 'name')>Name</option>
        <option value="created" @selected(($sort ?? '') === 'created')>Recently added</option>
        <option value="email" @selected(($sort ?? '') === 'email')>Email</option>
    </select>
    <select name="direction" class="rounded-lg border border-slate-300 bg-white px-3 py-2" aria-label="Sort direction">
        <option value="asc" @selected(($direction ?? 'asc') === 'asc')>A–Z / oldest</option>
        <option value="desc" @selected(($direction ?? '') === 'desc')>Z–A / newest</option>
    </select>
    <button class="rounded-lg bg-slate-950 px-4 py-2 font-semibold text-white hover:bg-slate-800">Apply</button>
</form>
