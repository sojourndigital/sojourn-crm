<?php

namespace App\Models;

use Database\Factories\IdentityProviderFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

#[Fillable(['user_id', 'provider', 'provider_user_id', 'provider_email', 'profile'])]
class IdentityProvider extends Model
{
    /** @use HasFactory<IdentityProviderFactory> */
    use HasFactory;

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    protected function casts(): array
    {
        return ['profile' => 'array'];
    }
}
