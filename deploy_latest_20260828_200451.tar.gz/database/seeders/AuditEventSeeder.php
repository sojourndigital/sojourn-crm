<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class AuditEventSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //
    }
}
