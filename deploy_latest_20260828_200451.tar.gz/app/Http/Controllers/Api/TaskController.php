<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreTaskRequest;
use App\Http\Requests\UpdateTaskRequest;
use App\Models\Task;
use App\Models\Workspace;
use App\Services\AuditLogger;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class TaskController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Workspace $workspace): JsonResponse
    {
        return response()->json($workspace->tasks()->with('assignedUser')->orderByRaw('case when due_at is null then 1 else 0 end')->orderBy('due_at')->orderBy('id')->paginate(25));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreTaskRequest $request, Workspace $workspace, AuditLogger $auditLogger): JsonResponse
    {
        $attributes = $request->validated();

        if (($attributes['status'] ?? 'open') === 'completed') {
            $attributes['completed_at'] = now();
            $attributes['completed_by_user_id'] = $request->user()->id;
        }

        $task = DB::transaction(function () use ($workspace, $attributes, $request, $auditLogger): Task {
            $task = $workspace->tasks()->create($attributes);
            $auditLogger->record($task, $workspace, $request->user(), 'task.created');

            return $task;
        });

        return response()->json($task->load('assignedUser'), 201);
    }

    /**
     * Display the specified resource.
     */
    public function show(Workspace $workspace, Task $task): JsonResponse
    {
        return response()->json($task->load(['assignedUser', 'completedByUser', 'subject']));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateTaskRequest $request, Workspace $workspace, Task $task, AuditLogger $auditLogger): JsonResponse
    {
        $attributes = $request->validated();

        if (($attributes['status'] ?? $task->status) === 'completed' && $task->completed_at === null) {
            $attributes['completed_at'] = now();
            $attributes['completed_by_user_id'] = $request->user()->id;
        }

        if (($attributes['status'] ?? $task->status) === 'open') {
            $attributes['completed_at'] = null;
            $attributes['completed_by_user_id'] = null;
        }

        DB::transaction(function () use ($task, $workspace, $request, $attributes, $auditLogger): void {
            $before = $task->getOriginal();
            $task->update($attributes);
            $auditLogger->record($task, $workspace, $request->user(), 'task.updated', $before);
        });

        return response()->json($task->refresh()->load('assignedUser'));
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Workspace $workspace, Task $task, AuditLogger $auditLogger): JsonResponse
    {
        DB::transaction(function () use ($task, $workspace, $auditLogger): void {
            $before = $task->getAttributes();
            $task->delete();
            $auditLogger->record($task, $workspace, request()->user(), 'task.deleted', $before);
        });

        return response()->json(status: 204);
    }
}
