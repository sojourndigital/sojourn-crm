<?php

namespace Database\Factories;

use App\Models\IdentityProvider;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<IdentityProvider>
 */
class IdentityProviderFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'user_id' => User::factory(),
            'provider' => 'microsoft',
            'provider_user_id' => fake()->unique()->uuid(),
            'provider_email' => fake()->safeEmail(),
            'profile' => [],
        ];
    }
}
