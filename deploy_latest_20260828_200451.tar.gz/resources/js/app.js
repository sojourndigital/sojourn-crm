const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content');

const announce = (message, type = 'status') => {
    let region = document.querySelector('[data-crm-announcements]');

    if (region === null) {
        region = document.createElement('div');
        region.dataset.crmAnnouncements = '';
        region.className = 'fixed right-4 bottom-4 z-50 max-w-sm rounded-xl border px-4 py-3 text-sm font-medium shadow-lg';
        document.body.append(region);
    }

    region.setAttribute('role', type === 'error' ? 'alert' : 'status');
    region.setAttribute('aria-live', type === 'error' ? 'assertive' : 'polite');
    region.classList.toggle('border-red-200', type === 'error');
    region.classList.toggle('bg-red-50', type === 'error');
    region.classList.toggle('text-red-700', type === 'error');
    region.classList.toggle('border-slate-200', type !== 'error');
    region.classList.toggle('bg-white', type !== 'error');
    region.classList.toggle('text-slate-700', type !== 'error');
    region.textContent = message;
};

document.querySelectorAll('[data-crm-form]').forEach((form) => {
    form.addEventListener('submit', async (event) => {
        event.preventDefault();

        const error = form.querySelector('[data-form-error]');
        const submit = form.querySelector('button[type="submit"]');

        if (error !== null) {
            error.textContent = '';
            error.classList.add('hidden');
        }

        if (submit !== null) {
            submit.disabled = true;
            submit.textContent = 'Saving…';
        }

        try {
            const response = await fetch(form.action, {
                method: form.method,
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken ?? '',
                },
                body: JSON.stringify(Object.fromEntries(new FormData(form))),
            });

            if (response.ok) {
                window.location.reload();

                return;
            }

            const payload = await response.json();
            const messages = Object.values(payload.errors ?? {}).flat().join(' ');
            throw new Error(messages || payload.message || 'Something went wrong. Please try again.');
        } catch (exception) {
            const message = exception instanceof Error ? exception.message : 'Something went wrong. Please try again.';

            if (error !== null) {
                error.textContent = message;
                error.classList.remove('hidden');
            }

            announce(message, 'error');
        } finally {
            if (submit !== null) {
                submit.disabled = false;
                submit.textContent = submit.dataset.defaultLabel ?? 'Save';
            }
        }
    });
});

document.querySelectorAll('[data-complete-task]').forEach((button) => {
    button.addEventListener('click', async () => {
        button.disabled = true;
        button.textContent = 'Completing…';

        try {
            const response = await fetch(button.dataset.completeTask, {
                method: 'PATCH',
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken ?? '',
                },
                body: JSON.stringify({ status: 'completed' }),
            });

            if (!response.ok) {
                throw new Error('Unable to complete this task. Please try again.');
            }

            window.location.reload();
        } catch (exception) {
            button.disabled = false;
            button.textContent = exception instanceof Error ? 'Try again' : 'Complete';
            announce('Unable to complete this task. Please try again.', 'error');
        }
    });
});

document.querySelectorAll('[data-deal-stage]').forEach((select) => {
    select.addEventListener('change', async () => {
        select.disabled = true;

        try {
            const response = await fetch(select.dataset.dealStage, {
                method: 'PATCH',
                headers: {
                    Accept: 'application/json',
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken ?? '',
                },
                body: JSON.stringify({ stage: select.value }),
            });

            if (!response.ok) {
                throw new Error('Unable to move this deal. Please try again.');
            }

            window.location.reload();
        } catch (exception) {
            select.disabled = false;
            announce(exception instanceof Error ? exception.message : 'Unable to move this deal. Please try again.', 'error');
        }
    });
});
