<?php

namespace Database\Factories;

use App\Models\Activity;
use App\Models\Workspace;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<Activity>
 */
class ActivityFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'workspace_id' => Workspace::factory(),
            'actor_user_id' => null,
            'subject_type' => null,
            'subject_id' => null,
            'type' => 'note',
            'body' => fake()->sentence(),
            'occurred_at' => now(),
            'metadata' => [],
        ];
    }
}
