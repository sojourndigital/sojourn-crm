<?php

namespace Database\Seeders;

use App\Models\Activity;
use App\Models\Company;
use App\Models\Contact;
use App\Models\Deal;
use App\Models\Task;
use App\Models\User;
use App\Models\Workspace;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

/**
 * Volume demo data for click-through evaluation. Synthetic only — never run against a workspace
 * that has real records. Requires DatabaseSeeder to have already created the base workspace/admin.
 */
class DemoDataSeeder extends Seeder
{
    use WithoutModelEvents;

    private const array STAGES = ['new', 'qualified', 'proposal', 'negotiation', 'closed_won', 'closed_lost'];

    private const array LIFECYCLE_STAGES = ['subscriber', 'lead', 'marketing_qualified', 'sales_qualified', 'opportunity', 'customer'];

    public function run(): void
    {
        $workspace = Workspace::query()->where('slug', 'northstar-property-care')->firstOrFail();
        $admin = User::query()->where('email', 'admin@example.test')->firstOrFail();

        $companies = Company::factory()
            ->for($workspace)
            ->count(18)
            ->create();

        $contacts = $companies->flatMap(fn (Company $company) => Contact::factory()
            ->for($workspace)
            ->for($company)
            ->count(fake()->numberBetween(1, 4))
            ->create(['lifecycle_stage' => fake()->randomElement(self::LIFECYCLE_STAGES)])
        )->merge(
            Contact::factory()->for($workspace)->count(10)->create(['lifecycle_stage' => fake()->randomElement(self::LIFECYCLE_STAGES)])
        );

        $deals = collect();

        foreach ($contacts->random(35) as $contact) {
            $stage = fake()->randomElement(self::STAGES);
            $isClosed = in_array($stage, ['closed_won', 'closed_lost'], true);

            $deals->push(Deal::factory()->for($workspace)
                ->for($contact, 'contact')
                ->create([
                    'company_id' => $contact->company_id,
                    'stage' => $stage,
                    'probability' => match ($stage) {
                        'new' => 10,
                        'qualified' => 30,
                        'proposal' => 55,
                        'negotiation' => 75,
                        'closed_won' => 100,
                        'closed_lost' => 0,
                    },
                    'closed_at' => $isClosed ? fake()->dateTimeBetween('-60 days', 'now') : null,
                ]));
        }

        foreach ($contacts->random(50) as $contact) {
            Activity::factory()->for($workspace)->for($admin, 'actor')->for($contact, 'subject')->create();
        }

        foreach ($deals->random(25) as $deal) {
            Task::factory()->for($workspace)->for($admin, 'assignedUser')->for($deal, 'subject')->create([
                'completed_at' => fake()->boolean(40) ? fake()->dateTimeBetween('-14 days', 'now') : null,
            ]);
        }

        $this->command?->info(sprintf(
            'Demo data: %d companies, %d contacts, %d deals seeded into workspace %s.',
            $companies->count(),
            $contacts->count(),
            $deals->count(),
            $workspace->slug,
        ));
    }
}
