<?php

namespace Tests\Feature;

use App\Models\Company;
use App\Models\Contact;
use App\Models\Deal;
use App\Models\Membership;
use App\Models\User;
use App\Models\Workspace;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class WorkspaceCompaniesTest extends TestCase
{
    use RefreshDatabase;

    public function test_member_can_search_only_companies_in_their_workspace(): void
    {
        $user = User::factory()->create();
        $workspace = Workspace::factory()->create(['name' => 'North Workspace']);
        Membership::factory()->create(['user_id' => $user->id, 'workspace_id' => $workspace->id]);
        Company::factory()->create(['workspace_id' => $workspace->id, 'name' => 'Northstar Services', 'domain' => 'northstar.test']);
        Company::factory()->create(['workspace_id' => $workspace->id, 'name' => 'Unrelated Company']);
        Company::factory()->create(['name' => 'Northstar Other Workspace']);

        $response = $this->actingAs($user)->get(route('workspace.companies', [$workspace, 'q' => 'northstar']));

        $response->assertOk();
        $response->assertSee('Northstar Services');
        $response->assertDontSee('Unrelated Company');
        $response->assertDontSee('Northstar Other Workspace');
    }

    public function test_member_cannot_open_another_workspaces_companies(): void
    {
        $user = User::factory()->create();
        $workspace = Workspace::factory()->create();
        $otherWorkspace = Workspace::factory()->create();
        Membership::factory()->create(['user_id' => $user->id, 'workspace_id' => $workspace->id]);

        $this->actingAs($user)
            ->get(route('workspace.companies', $otherWorkspace))
            ->assertNotFound();
    }

    public function test_member_can_open_a_company_detail_page_with_contacts_and_deals(): void
    {
        $user = User::factory()->create();
        $workspace = Workspace::factory()->create();
        Membership::factory()->create(['user_id' => $user->id, 'workspace_id' => $workspace->id]);
        $company = Company::factory()->create(['workspace_id' => $workspace->id, 'name' => 'Northstar Services']);
        Contact::factory()->create(['workspace_id' => $workspace->id, 'company_id' => $company->id, 'first_name' => 'Avery', 'last_name' => 'Reed']);
        Deal::factory()->create(['workspace_id' => $workspace->id, 'company_id' => $company->id, 'name' => 'Annual contract']);

        $this->actingAs($user)
            ->get(route('workspace.company', [$workspace, $company]))
            ->assertOk()
            ->assertSee('Northstar Services')
            ->assertSee('Avery Reed')
            ->assertSee('Annual contract');
    }
}
