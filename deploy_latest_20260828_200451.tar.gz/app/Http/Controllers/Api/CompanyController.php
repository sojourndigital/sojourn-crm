<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreCompanyRequest;
use App\Http\Requests\UpdateCompanyRequest;
use App\Models\Company;
use App\Models\Workspace;
use App\Services\AuditLogger;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class CompanyController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Workspace $workspace): JsonResponse
    {
        return response()->json($workspace->companies()->orderByDesc('created_at')->orderByDesc('id')->paginate(25));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreCompanyRequest $request, Workspace $workspace, AuditLogger $auditLogger): JsonResponse
    {
        $company = DB::transaction(function () use ($workspace, $request, $auditLogger): Company {
            $company = $workspace->companies()->create($request->validated());
            $auditLogger->record($company, $workspace, $request->user(), 'company.created');

            return $company;
        });

        return response()->json($company, 201);
    }

    /**
     * Display the specified resource.
     */
    public function show(Workspace $workspace, Company $company): JsonResponse
    {
        return response()->json($company->loadCount(['contacts', 'deals']));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateCompanyRequest $request, Workspace $workspace, Company $company, AuditLogger $auditLogger): JsonResponse
    {
        DB::transaction(function () use ($company, $workspace, $request, $auditLogger): void {
            $before = $company->getOriginal();
            $company->update($request->validated());
            $auditLogger->record($company, $workspace, $request->user(), 'company.updated', $before);
        });

        return response()->json($company->refresh());
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Workspace $workspace, Company $company, AuditLogger $auditLogger): JsonResponse
    {
        abort_unless(request()->user()->isWorkspaceAdmin($workspace), 403);
        DB::transaction(function () use ($company, $workspace, $auditLogger): void {
            $before = $company->getAttributes();
            $company->delete();
            $auditLogger->record($company, $workspace, request()->user(), 'company.deleted', $before);
        });

        return response()->json(status: 204);
    }
}
