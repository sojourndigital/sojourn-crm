<?php

namespace App\Http\Controllers;

use App\Models\Company;
use App\Models\Workspace;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

class WorkspaceCompanyController extends Controller
{
    public function index(Request $request, Workspace $workspace): View
    {
        $search = $request->string('q')->trim()->substr(0, 100)->toString();

        $sort = $request->string('sort')->toString();
        $direction = $request->string('direction')->lower()->toString() === 'desc' ? 'desc' : 'asc';
        $sortColumn = ['name' => 'name', 'domain' => 'domain', 'created' => 'created_at'][$sort] ?? 'name';
        $companies = Company::query()
            ->whereBelongsTo($workspace)
            ->select(['id', 'workspace_id', 'name', 'domain', 'phone', 'created_at'])
            ->withCount(['contacts', 'deals'])
            ->when($search !== '', function ($query) use ($search): void {
                $pattern = '%'.mb_strtolower($search).'%';

                $query->where(function ($query) use ($pattern): void {
                    $query->whereRaw('lower(name) like ?', [$pattern])
                        ->orWhereRaw('lower(domain) like ?', [$pattern])
                        ->orWhereRaw('lower(phone) like ?', [$pattern]);
                });
            })
            ->orderBy($sortColumn, $direction)
            ->orderBy('id')
            ->paginate(25)
            ->withQueryString();

        return view('companies.index', [
            'workspace' => $workspace,
            'companies' => $companies,
            'search' => $search,
            'sort' => $sort,
            'direction' => $direction,
        ]);
    }

    public function show(Workspace $workspace, Company $company): View
    {
        $company->load([
            'contacts' => fn ($query) => $query->orderBy('last_name')->orderBy('first_name')->orderBy('id'),
            'deals' => fn ($query) => $query->orderByDesc('amount')->orderByDesc('id'),
            'activities' => fn ($query) => $query->with('actor:id,name')->latest('occurred_at')->latest('id')->limit(20),
        ]);

        return view('companies.show', ['workspace' => $workspace, 'company' => $company]);
    }
}
