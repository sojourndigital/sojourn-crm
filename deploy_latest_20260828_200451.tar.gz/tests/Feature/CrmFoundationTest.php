<?php

namespace Tests\Feature;

use App\Models\Activity;
use App\Models\AuditEvent;
use App\Models\Company;
use App\Models\Contact;
use App\Models\Deal;
use App\Models\Task;
use App\Models\Workspace;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class CrmFoundationTest extends TestCase
{
    use RefreshDatabase;

    public function test_workspace_records_keep_their_relationships(): void
    {
        $workspace = Workspace::factory()->create();
        $company = Company::factory()->for($workspace)->create();
        $contact = Contact::factory()->for($workspace)->for($company)->create();
        $deal = Deal::factory()->for($workspace)->for($company)->for($contact)->create();

        Activity::factory()->for($workspace)->for($contact, 'subject')->create();
        Task::factory()->for($workspace)->for($deal, 'subject')->create();
        AuditEvent::factory()->for($workspace)->for($deal, 'auditable')->create();

        $this->assertSame(1, $workspace->contacts()->count());
        $this->assertSame(1, $workspace->deals()->count());
        $this->assertSame(1, $contact->activities()->count());
        $this->assertSame(1, $deal->tasks()->count());
        $this->assertSame(1, $deal->auditEvents()->count());
    }

    public function test_workspaces_do_not_share_contacts(): void
    {
        $firstWorkspace = Workspace::factory()->create();
        $secondWorkspace = Workspace::factory()->create();

        Contact::factory()->for($firstWorkspace)->create();
        Contact::factory()->for($secondWorkspace)->create();

        $this->assertSame(1, $firstWorkspace->contacts()->count());
        $this->assertSame(1, $secondWorkspace->contacts()->count());
    }
}
