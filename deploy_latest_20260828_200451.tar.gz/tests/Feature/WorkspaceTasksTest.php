<?php

namespace Tests\Feature;

use App\Models\Membership;
use App\Models\Task;
use App\Models\User;
use App\Models\Workspace;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class WorkspaceTasksTest extends TestCase
{
    use RefreshDatabase;

    public function test_member_sees_open_tasks_only_from_their_workspace(): void
    {
        $user = User::factory()->create();
        $workspace = Workspace::factory()->create(['name' => 'North Workspace']);
        Membership::factory()->create(['user_id' => $user->id, 'workspace_id' => $workspace->id]);
        Task::factory()->create(['workspace_id' => $workspace->id, 'title' => 'Visible task', 'status' => 'open']);
        Task::factory()->create(['workspace_id' => $workspace->id, 'title' => 'Completed task', 'status' => 'completed']);
        Task::factory()->create(['title' => 'Other task', 'status' => 'open']);

        $response = $this->actingAs($user)->get(route('workspace.tasks', $workspace));

        $response->assertOk();
        $response->assertSee('Visible task');
        $response->assertDontSee('Completed task');
        $response->assertDontSee('Other task');
    }

    public function test_member_cannot_open_another_workspaces_task_queue(): void
    {
        $user = User::factory()->create();
        $workspace = Workspace::factory()->create();
        $otherWorkspace = Workspace::factory()->create();
        Membership::factory()->create(['user_id' => $user->id, 'workspace_id' => $workspace->id]);

        $this->actingAs($user)
            ->get(route('workspace.tasks', $otherWorkspace))
            ->assertNotFound();
    }
}
