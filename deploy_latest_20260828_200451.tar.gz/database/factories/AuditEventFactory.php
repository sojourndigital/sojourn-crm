<?php

namespace Database\Factories;

use App\Models\AuditEvent;
use App\Models\Workspace;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<AuditEvent>
 */
class AuditEventFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'workspace_id' => Workspace::factory(),
            'actor_user_id' => null,
            'auditable_type' => null,
            'auditable_id' => null,
            'action' => 'created',
            'source' => 'application',
            'request_id' => fake()->uuid(),
            'before' => null,
            'after' => [],
            'occurred_at' => now(),
        ];
    }
}
